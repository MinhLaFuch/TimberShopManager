﻿namespace timber_shop_manager
{
    partial class frmSale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSale));
            btnClear = new Guna.UI2.WinForms.Guna2Button();
            btnAddProduct = new Guna.UI2.WinForms.Guna2Button();
            lbSelectProduct = new Label();
            btnCreate = new Guna.UI2.WinForms.Guna2Button();
            btnConfirm = new Guna.UI2.WinForms.Guna2Button();
            btnCancel = new Guna.UI2.WinForms.Guna2Button();
            pnButton = new FlowLayoutPanel();
            gbInvoice = new Guna.UI2.WinForms.Guna2GroupBox();
            pnPurchase = new Panel();
            lbPaymentMethod = new Label();
            pnPaymentMethod = new Panel();
            rdTransfer = new Guna.UI2.WinForms.Guna2RadioButton();
            rdCash = new Guna.UI2.WinForms.Guna2RadioButton();
            lbVoucherId = new Label();
            cbVoucher = new ComboBox();
            lbCurrency = new Label();
            txtTotal = new TextBox();
            lbTotal = new Label();
            txtProductQuantity = new TextBox();
            lbProductQuantity = new Label();
            pnInvoiceInfo = new Panel();
            dtpDate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            txtEmployeeName = new TextBox();
            lbID = new Label();
            lbDate = new Label();
            lbEmployee = new Label();
            txtId = new TextBox();
            gbCustomer = new Guna.UI2.WinForms.Guna2GroupBox();
            pnCustomer = new Panel();
            txtPhoneNumber = new TextBox();
            txtCustomerName = new TextBox();
            lbCustomerName = new Label();
            lbPhoneNumber = new Label();
            lbAddress = new Label();
            txtAddress = new TextBox();
            fpnBtnCustomer = new FlowLayoutPanel();
            btnAddCustomer = new Guna.UI2.WinForms.Guna2Button();
            dgvProduct = new Guna.UI2.WinForms.Guna2DataGridView();
            pnInfo = new FlowLayoutPanel();
            pnFindProduct = new Panel();
            btnRemoveAll = new Guna.UI2.WinForms.Guna2Button();
            btnDelete = new Guna.UI2.WinForms.Guna2Button();
            lbUnit = new Label();
            lbAmount = new Label();
            txtProductName = new TextBox();
            nudQuantity = new Guna.UI2.WinForms.Guna2NumericUpDown();
            dgvSale = new Guna.UI2.WinForms.Guna2DataGridView();
            pnButton.SuspendLayout();
            gbInvoice.SuspendLayout();
            pnPurchase.SuspendLayout();
            pnPaymentMethod.SuspendLayout();
            pnInvoiceInfo.SuspendLayout();
            gbCustomer.SuspendLayout();
            pnCustomer.SuspendLayout();
            fpnBtnCustomer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvProduct).BeginInit();
            pnInfo.SuspendLayout();
            pnFindProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudQuantity).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvSale).BeginInit();
            SuspendLayout();
            // 
            // btnClear
            // 
            btnClear.CustomizableEdges = customizableEdges1;
            btnClear.DisabledState.BorderColor = Color.DarkGray;
            btnClear.DisabledState.CustomBorderColor = Color.DarkGray;
            btnClear.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnClear.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnClear.Dock = DockStyle.Bottom;
            btnClear.FillColor = Color.FromArgb(59, 93, 79);
            btnClear.Font = new Font("Segoe UI", 9F);
            btnClear.ForeColor = Color.White;
            btnClear.Location = new Point(125, 3);
            btnClear.Name = "btnClear";
            btnClear.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnClear.Size = new Size(107, 33);
            btnClear.TabIndex = 1;
            btnClear.Text = "Làm mới";
            btnClear.Click += btnClear_Click;
            // 
            // btnAddProduct
            // 
            btnAddProduct.CustomizableEdges = customizableEdges3;
            btnAddProduct.DisabledState.BorderColor = Color.DarkGray;
            btnAddProduct.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAddProduct.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAddProduct.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAddProduct.FillColor = Color.FromArgb(59, 93, 79);
            btnAddProduct.Font = new Font("Segoe UI", 9F);
            btnAddProduct.ForeColor = Color.White;
            btnAddProduct.Location = new Point(619, 3);
            btnAddProduct.Name = "btnAddProduct";
            btnAddProduct.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnAddProduct.Size = new Size(170, 53);
            btnAddProduct.TabIndex = 5;
            btnAddProduct.Text = "Thêm";
            btnAddProduct.Click += btnAddProduct_Click;
            // 
            // lbSelectProduct
            // 
            lbSelectProduct.AutoSize = true;
            lbSelectProduct.ForeColor = Color.FromArgb(59, 93, 79);
            lbSelectProduct.Location = new Point(25, 19);
            lbSelectProduct.Name = "lbSelectProduct";
            lbSelectProduct.Size = new Size(75, 20);
            lbSelectProduct.TabIndex = 0;
            lbSelectProduct.Text = "Sản phẩm";
            // 
            // btnCreate
            // 
            btnCreate.CustomizableEdges = customizableEdges5;
            btnCreate.DisabledState.BorderColor = Color.DarkGray;
            btnCreate.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCreate.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCreate.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCreate.FillColor = Color.FromArgb(59, 93, 79);
            btnCreate.Font = new Font("Segoe UI", 9F);
            btnCreate.ForeColor = Color.White;
            btnCreate.Location = new Point(3, 3);
            btnCreate.Name = "btnCreate";
            btnCreate.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnCreate.Size = new Size(130, 32);
            btnCreate.TabIndex = 0;
            btnCreate.Text = "Tạo phiếu";
            btnCreate.Click += btnCreate_Click;
            // 
            // btnConfirm
            // 
            btnConfirm.CustomizableEdges = customizableEdges7;
            btnConfirm.DisabledState.BorderColor = Color.DarkGray;
            btnConfirm.DisabledState.CustomBorderColor = Color.DarkGray;
            btnConfirm.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnConfirm.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnConfirm.FillColor = Color.FromArgb(59, 93, 79);
            btnConfirm.Font = new Font("Segoe UI", 9F);
            btnConfirm.ForeColor = Color.White;
            btnConfirm.Location = new Point(275, 3);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnConfirm.Size = new Size(130, 32);
            btnConfirm.TabIndex = 2;
            btnConfirm.Text = "Lập hóa đơn";
            btnConfirm.Click += btnConfirm_Click;
            // 
            // btnCancel
            // 
            btnCancel.CustomizableEdges = customizableEdges9;
            btnCancel.DisabledState.BorderColor = Color.DarkGray;
            btnCancel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCancel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCancel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCancel.FillColor = Color.FromArgb(59, 93, 79);
            btnCancel.Font = new Font("Segoe UI", 9F);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(139, 3);
            btnCancel.Name = "btnCancel";
            btnCancel.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnCancel.Size = new Size(130, 32);
            btnCancel.TabIndex = 1;
            btnCancel.Text = "Hủy phiếu";
            btnCancel.Click += btnCancel_Click;
            // 
            // pnButton
            // 
            pnButton.Controls.Add(btnCreate);
            pnButton.Controls.Add(btnCancel);
            pnButton.Controls.Add(btnConfirm);
            pnButton.Location = new Point(378, 211);
            pnButton.Name = "pnButton";
            pnButton.Size = new Size(418, 43);
            pnButton.TabIndex = 2;
            // 
            // gbInvoice
            // 
            gbInvoice.Controls.Add(pnPurchase);
            gbInvoice.Controls.Add(pnInvoiceInfo);
            gbInvoice.Controls.Add(pnButton);
            gbInvoice.CustomBorderColor = Color.FromArgb(59, 93, 79);
            gbInvoice.CustomizableEdges = customizableEdges13;
            gbInvoice.FillColor = SystemColors.Control;
            gbInvoice.Font = new Font("Segoe UI", 9F);
            gbInvoice.ForeColor = Color.White;
            gbInvoice.Location = new Point(3, 3);
            gbInvoice.Name = "gbInvoice";
            gbInvoice.ShadowDecoration.CustomizableEdges = customizableEdges14;
            gbInvoice.Size = new Size(797, 259);
            gbInvoice.TabIndex = 0;
            gbInvoice.Text = "Hóa đơn";
            // 
            // pnPurchase
            // 
            pnPurchase.Controls.Add(lbPaymentMethod);
            pnPurchase.Controls.Add(pnPaymentMethod);
            pnPurchase.Controls.Add(lbVoucherId);
            pnPurchase.Controls.Add(cbVoucher);
            pnPurchase.Controls.Add(lbCurrency);
            pnPurchase.Controls.Add(txtTotal);
            pnPurchase.Controls.Add(lbTotal);
            pnPurchase.Controls.Add(txtProductQuantity);
            pnPurchase.Controls.Add(lbProductQuantity);
            pnPurchase.Location = new Point(425, 43);
            pnPurchase.Name = "pnPurchase";
            pnPurchase.Size = new Size(371, 155);
            pnPurchase.TabIndex = 1;
            // 
            // lbPaymentMethod
            // 
            lbPaymentMethod.AutoSize = true;
            lbPaymentMethod.BackColor = Color.Transparent;
            lbPaymentMethod.ForeColor = Color.FromArgb(59, 93, 79);
            lbPaymentMethod.Location = new Point(11, 81);
            lbPaymentMethod.Name = "lbPaymentMethod";
            lbPaymentMethod.Size = new Size(83, 20);
            lbPaymentMethod.TabIndex = 4;
            lbPaymentMethod.Text = "Thanh toán";
            // 
            // pnPaymentMethod
            // 
            pnPaymentMethod.Controls.Add(rdTransfer);
            pnPaymentMethod.Controls.Add(rdCash);
            pnPaymentMethod.Location = new Point(113, 69);
            pnPaymentMethod.Margin = new Padding(3, 4, 3, 4);
            pnPaymentMethod.Name = "pnPaymentMethod";
            pnPaymentMethod.Size = new Size(216, 41);
            pnPaymentMethod.TabIndex = 5;
            // 
            // rdTransfer
            // 
            rdTransfer.AutoSize = true;
            rdTransfer.CheckedState.BorderColor = Color.FromArgb(94, 148, 255);
            rdTransfer.CheckedState.BorderThickness = 0;
            rdTransfer.CheckedState.FillColor = Color.FromArgb(94, 148, 255);
            rdTransfer.CheckedState.InnerColor = Color.White;
            rdTransfer.CheckedState.InnerOffset = -4;
            rdTransfer.FlatStyle = FlatStyle.Flat;
            rdTransfer.ForeColor = Color.FromArgb(59, 93, 79);
            rdTransfer.Location = new Point(94, 7);
            rdTransfer.Margin = new Padding(3, 4, 3, 4);
            rdTransfer.Name = "rdTransfer";
            rdTransfer.Size = new Size(121, 24);
            rdTransfer.TabIndex = 1;
            rdTransfer.Text = "Chuyển khoản";
            rdTransfer.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            rdTransfer.UncheckedState.BorderThickness = 2;
            rdTransfer.UncheckedState.FillColor = Color.Transparent;
            rdTransfer.UncheckedState.InnerColor = Color.Transparent;
            // 
            // rdCash
            // 
            rdCash.AutoSize = true;
            rdCash.Checked = true;
            rdCash.CheckedState.BorderColor = Color.FromArgb(94, 148, 255);
            rdCash.CheckedState.BorderThickness = 0;
            rdCash.CheckedState.FillColor = Color.FromArgb(94, 148, 255);
            rdCash.CheckedState.InnerColor = Color.White;
            rdCash.CheckedState.InnerOffset = -4;
            rdCash.FlatStyle = FlatStyle.Flat;
            rdCash.ForeColor = Color.FromArgb(59, 93, 79);
            rdCash.Location = new Point(3, 7);
            rdCash.Margin = new Padding(3, 4, 3, 4);
            rdCash.Name = "rdCash";
            rdCash.Size = new Size(87, 24);
            rdCash.TabIndex = 0;
            rdCash.TabStop = true;
            rdCash.Text = "Tiền mặt";
            rdCash.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            rdCash.UncheckedState.BorderThickness = 2;
            rdCash.UncheckedState.FillColor = Color.Transparent;
            rdCash.UncheckedState.InnerColor = Color.Transparent;
            // 
            // lbVoucherId
            // 
            lbVoucherId.AutoSize = true;
            lbVoucherId.ForeColor = Color.FromArgb(59, 93, 79);
            lbVoucherId.Location = new Point(14, 44);
            lbVoucherId.Name = "lbVoucherId";
            lbVoucherId.Size = new Size(93, 20);
            lbVoucherId.TabIndex = 2;
            lbVoucherId.Text = "Mã giảm giá";
            // 
            // cbVoucher
            // 
            cbVoucher.ForeColor = Color.FromArgb(59, 93, 79);
            cbVoucher.FormattingEnabled = true;
            cbVoucher.Location = new Point(115, 40);
            cbVoucher.Margin = new Padding(3, 4, 3, 4);
            cbVoucher.Name = "cbVoucher";
            cbVoucher.Size = new Size(174, 28);
            cbVoucher.TabIndex = 3;
            cbVoucher.SelectedIndexChanged += cbVoucher_SelectedIndexChanged;
            // 
            // lbCurrency
            // 
            lbCurrency.AutoSize = true;
            lbCurrency.BackColor = Color.Transparent;
            lbCurrency.ForeColor = Color.FromArgb(59, 93, 79);
            lbCurrency.Location = new Point(296, 119);
            lbCurrency.Name = "lbCurrency";
            lbCurrency.Size = new Size(40, 20);
            lbCurrency.TabIndex = 8;
            lbCurrency.Text = "VND";
            // 
            // txtTotal
            // 
            txtTotal.BackColor = Color.White;
            txtTotal.BorderStyle = BorderStyle.None;
            txtTotal.Enabled = false;
            txtTotal.ForeColor = Color.FromArgb(59, 93, 79);
            txtTotal.Location = new Point(115, 119);
            txtTotal.Margin = new Padding(3, 4, 3, 4);
            txtTotal.Name = "txtTotal";
            txtTotal.Size = new Size(175, 20);
            txtTotal.TabIndex = 7;
            txtTotal.TextChanged += txtTotal_TextChanged;
            // 
            // lbTotal
            // 
            lbTotal.AutoSize = true;
            lbTotal.BackColor = Color.Transparent;
            lbTotal.ForeColor = Color.FromArgb(59, 93, 79);
            lbTotal.Location = new Point(11, 119);
            lbTotal.Name = "lbTotal";
            lbTotal.Size = new Size(78, 20);
            lbTotal.TabIndex = 6;
            lbTotal.Text = "Thành tiền";
            // 
            // txtProductQuantity
            // 
            txtProductQuantity.BackColor = Color.White;
            txtProductQuantity.BorderStyle = BorderStyle.None;
            txtProductQuantity.Enabled = false;
            txtProductQuantity.ForeColor = Color.FromArgb(59, 93, 79);
            txtProductQuantity.Location = new Point(115, 5);
            txtProductQuantity.Margin = new Padding(3, 4, 3, 4);
            txtProductQuantity.Name = "txtProductQuantity";
            txtProductQuantity.Size = new Size(175, 20);
            txtProductQuantity.TabIndex = 1;
            txtProductQuantity.TextChanged += txtProductQuantity_TextChanged;
            // 
            // lbProductQuantity
            // 
            lbProductQuantity.AutoSize = true;
            lbProductQuantity.BackColor = Color.Transparent;
            lbProductQuantity.ForeColor = Color.FromArgb(59, 93, 79);
            lbProductQuantity.Location = new Point(11, 5);
            lbProductQuantity.Name = "lbProductQuantity";
            lbProductQuantity.Size = new Size(94, 20);
            lbProductQuantity.TabIndex = 0;
            lbProductQuantity.Text = "Số sản phẩm";
            // 
            // pnInvoiceInfo
            // 
            pnInvoiceInfo.Controls.Add(dtpDate);
            pnInvoiceInfo.Controls.Add(txtEmployeeName);
            pnInvoiceInfo.Controls.Add(lbID);
            pnInvoiceInfo.Controls.Add(lbDate);
            pnInvoiceInfo.Controls.Add(lbEmployee);
            pnInvoiceInfo.Controls.Add(txtId);
            pnInvoiceInfo.Enabled = false;
            pnInvoiceInfo.Location = new Point(3, 43);
            pnInvoiceInfo.Name = "pnInvoiceInfo";
            pnInvoiceInfo.Size = new Size(406, 155);
            pnInvoiceInfo.TabIndex = 0;
            // 
            // dtpDate
            // 
            dtpDate.Checked = true;
            dtpDate.CustomFormat = "dd/MM/yyyy";
            dtpDate.CustomizableEdges = customizableEdges11;
            dtpDate.FillColor = Color.FromArgb(59, 93, 79);
            dtpDate.Font = new Font("Segoe UI", 9F);
            dtpDate.ForeColor = Color.White;
            dtpDate.Format = DateTimePickerFormat.Custom;
            dtpDate.Location = new Point(111, 51);
            dtpDate.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpDate.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpDate.Name = "dtpDate";
            dtpDate.ShadowDecoration.CustomizableEdges = customizableEdges12;
            dtpDate.Size = new Size(198, 45);
            dtpDate.TabIndex = 3;
            dtpDate.Value = new DateTime(2025, 4, 15, 22, 31, 0, 592);
            // 
            // txtEmployeeName
            // 
            txtEmployeeName.BackColor = Color.White;
            txtEmployeeName.BorderStyle = BorderStyle.None;
            txtEmployeeName.ForeColor = Color.FromArgb(59, 93, 79);
            txtEmployeeName.Location = new Point(111, 109);
            txtEmployeeName.Margin = new Padding(3, 4, 3, 4);
            txtEmployeeName.Name = "txtEmployeeName";
            txtEmployeeName.ReadOnly = true;
            txtEmployeeName.Size = new Size(198, 20);
            txtEmployeeName.TabIndex = 5;
            // 
            // lbID
            // 
            lbID.AutoSize = true;
            lbID.BackColor = Color.Transparent;
            lbID.ForeColor = Color.FromArgb(59, 93, 79);
            lbID.Location = new Point(5, 11);
            lbID.Name = "lbID";
            lbID.Size = new Size(26, 20);
            lbID.TabIndex = 0;
            lbID.Text = "Số";
            // 
            // lbDate
            // 
            lbDate.AutoSize = true;
            lbDate.BackColor = Color.Transparent;
            lbDate.ForeColor = Color.FromArgb(59, 93, 79);
            lbDate.Location = new Point(5, 51);
            lbDate.Name = "lbDate";
            lbDate.Size = new Size(69, 20);
            lbDate.TabIndex = 2;
            lbDate.Text = "Ngày lập";
            // 
            // lbEmployee
            // 
            lbEmployee.AutoSize = true;
            lbEmployee.BackColor = Color.Transparent;
            lbEmployee.ForeColor = Color.FromArgb(59, 93, 79);
            lbEmployee.Location = new Point(5, 109);
            lbEmployee.Name = "lbEmployee";
            lbEmployee.Size = new Size(75, 20);
            lbEmployee.TabIndex = 4;
            lbEmployee.Text = "Nhân viên";
            // 
            // txtId
            // 
            txtId.BackColor = Color.White;
            txtId.BorderStyle = BorderStyle.None;
            txtId.Enabled = false;
            txtId.ForeColor = Color.FromArgb(59, 93, 79);
            txtId.Location = new Point(111, 11);
            txtId.Margin = new Padding(3, 4, 3, 4);
            txtId.Name = "txtId";
            txtId.ReadOnly = true;
            txtId.Size = new Size(198, 20);
            txtId.TabIndex = 1;
            // 
            // gbCustomer
            // 
            gbCustomer.Controls.Add(pnCustomer);
            gbCustomer.Controls.Add(fpnBtnCustomer);
            gbCustomer.CustomBorderColor = Color.FromArgb(59, 93, 79);
            gbCustomer.CustomizableEdges = customizableEdges17;
            gbCustomer.FillColor = SystemColors.Control;
            gbCustomer.Font = new Font("Segoe UI", 9F);
            gbCustomer.ForeColor = Color.White;
            gbCustomer.Location = new Point(806, 3);
            gbCustomer.Name = "gbCustomer";
            gbCustomer.ShadowDecoration.CustomizableEdges = customizableEdges18;
            gbCustomer.Size = new Size(390, 259);
            gbCustomer.TabIndex = 1;
            gbCustomer.Text = "Khách hàng";
            // 
            // pnCustomer
            // 
            pnCustomer.Controls.Add(txtPhoneNumber);
            pnCustomer.Controls.Add(txtCustomerName);
            pnCustomer.Controls.Add(lbCustomerName);
            pnCustomer.Controls.Add(lbPhoneNumber);
            pnCustomer.Controls.Add(lbAddress);
            pnCustomer.Controls.Add(txtAddress);
            pnCustomer.Location = new Point(8, 43);
            pnCustomer.Name = "pnCustomer";
            pnCustomer.Size = new Size(363, 155);
            pnCustomer.TabIndex = 0;
            // 
            // txtPhoneNumber
            // 
            txtPhoneNumber.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtPhoneNumber.BackColor = Color.White;
            txtPhoneNumber.BorderStyle = BorderStyle.None;
            txtPhoneNumber.ForeColor = Color.FromArgb(59, 93, 79);
            txtPhoneNumber.Location = new Point(72, 5);
            txtPhoneNumber.Margin = new Padding(3, 4, 3, 4);
            txtPhoneNumber.Name = "txtPhoneNumber";
            txtPhoneNumber.Size = new Size(285, 20);
            txtPhoneNumber.TabIndex = 1;
            txtPhoneNumber.TextChanged += txtPhoneNumber_TextChanged;
            txtPhoneNumber.KeyPress += txtPhoneNumber_KeyPress;
            // 
            // txtCustomerName
            // 
            txtCustomerName.BackColor = Color.White;
            txtCustomerName.BorderStyle = BorderStyle.None;
            txtCustomerName.ForeColor = Color.FromArgb(59, 93, 79);
            txtCustomerName.Location = new Point(72, 40);
            txtCustomerName.Margin = new Padding(3, 4, 3, 4);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.Size = new Size(285, 20);
            txtCustomerName.TabIndex = 3;
            txtCustomerName.KeyPress += txtCustomerName_KeyPress;
            // 
            // lbCustomerName
            // 
            lbCustomerName.AutoSize = true;
            lbCustomerName.BackColor = Color.Transparent;
            lbCustomerName.ForeColor = Color.FromArgb(59, 93, 79);
            lbCustomerName.Location = new Point(3, 45);
            lbCustomerName.Name = "lbCustomerName";
            lbCustomerName.Size = new Size(32, 20);
            lbCustomerName.TabIndex = 2;
            lbCustomerName.Text = "Tên";
            // 
            // lbPhoneNumber
            // 
            lbPhoneNumber.AutoSize = true;
            lbPhoneNumber.BackColor = Color.Transparent;
            lbPhoneNumber.ForeColor = Color.FromArgb(59, 93, 79);
            lbPhoneNumber.Location = new Point(3, 11);
            lbPhoneNumber.Name = "lbPhoneNumber";
            lbPhoneNumber.Size = new Size(36, 20);
            lbPhoneNumber.TabIndex = 0;
            lbPhoneNumber.Text = "SĐT";
            // 
            // lbAddress
            // 
            lbAddress.AutoSize = true;
            lbAddress.BackColor = Color.Transparent;
            lbAddress.ForeColor = Color.FromArgb(59, 93, 79);
            lbAddress.Location = new Point(3, 79);
            lbAddress.Name = "lbAddress";
            lbAddress.Size = new Size(55, 20);
            lbAddress.TabIndex = 4;
            lbAddress.Text = "Địa chỉ";
            // 
            // txtAddress
            // 
            txtAddress.BackColor = Color.White;
            txtAddress.BorderStyle = BorderStyle.None;
            txtAddress.ForeColor = Color.FromArgb(59, 93, 79);
            txtAddress.Location = new Point(72, 75);
            txtAddress.Margin = new Padding(3, 4, 3, 4);
            txtAddress.Multiline = true;
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(285, 55);
            txtAddress.TabIndex = 5;
            // 
            // fpnBtnCustomer
            // 
            fpnBtnCustomer.Controls.Add(btnClear);
            fpnBtnCustomer.Controls.Add(btnAddCustomer);
            fpnBtnCustomer.FlowDirection = FlowDirection.RightToLeft;
            fpnBtnCustomer.Location = new Point(136, 211);
            fpnBtnCustomer.Name = "fpnBtnCustomer";
            fpnBtnCustomer.Size = new Size(235, 43);
            fpnBtnCustomer.TabIndex = 1;
            // 
            // btnAddCustomer
            // 
            btnAddCustomer.CustomizableEdges = customizableEdges15;
            btnAddCustomer.DisabledState.BorderColor = Color.DarkGray;
            btnAddCustomer.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAddCustomer.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAddCustomer.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAddCustomer.Dock = DockStyle.Bottom;
            btnAddCustomer.FillColor = Color.FromArgb(59, 93, 79);
            btnAddCustomer.Font = new Font("Segoe UI", 9F);
            btnAddCustomer.ForeColor = Color.White;
            btnAddCustomer.Location = new Point(12, 3);
            btnAddCustomer.Name = "btnAddCustomer";
            btnAddCustomer.ShadowDecoration.CustomizableEdges = customizableEdges16;
            btnAddCustomer.Size = new Size(107, 33);
            btnAddCustomer.TabIndex = 0;
            btnAddCustomer.Text = "Thêm";
            btnAddCustomer.Click += btnAddCustomer_Click;
            // 
            // dgvProduct
            // 
            dgvProduct.AllowUserToAddRows = false;
            dgvProduct.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.White;
            dgvProduct.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgvProduct.BackgroundColor = Color.Gainsboro;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgvProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgvProduct.ColumnHeadersHeight = 50;
            dgvProduct.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgvProduct.DefaultCellStyle = dataGridViewCellStyle3;
            dgvProduct.GridColor = Color.FromArgb(231, 229, 255);
            dgvProduct.Location = new Point(8, 327);
            dgvProduct.Name = "dgvProduct";
            dgvProduct.ReadOnly = true;
            dgvProduct.RowHeadersVisible = false;
            dgvProduct.RowHeadersWidth = 51;
            dgvProduct.Size = new Size(609, 528);
            dgvProduct.TabIndex = 2;
            dgvProduct.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgvProduct.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgvProduct.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgvProduct.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgvProduct.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgvProduct.ThemeStyle.BackColor = Color.Gainsboro;
            dgvProduct.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgvProduct.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgvProduct.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvProduct.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            dgvProduct.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgvProduct.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgvProduct.ThemeStyle.HeaderStyle.Height = 50;
            dgvProduct.ThemeStyle.ReadOnly = true;
            dgvProduct.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgvProduct.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvProduct.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            dgvProduct.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgvProduct.ThemeStyle.RowsStyle.Height = 29;
            dgvProduct.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgvProduct.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgvProduct.CellClick += dgvProduct_CellClick;
            // 
            // pnInfo
            // 
            pnInfo.Controls.Add(gbInvoice);
            pnInfo.Controls.Add(gbCustomer);
            pnInfo.Location = new Point(5, -7);
            pnInfo.Name = "pnInfo";
            pnInfo.Size = new Size(1200, 265);
            pnInfo.TabIndex = 0;
            // 
            // pnFindProduct
            // 
            pnFindProduct.Controls.Add(btnRemoveAll);
            pnFindProduct.Controls.Add(btnDelete);
            pnFindProduct.Controls.Add(lbUnit);
            pnFindProduct.Controls.Add(lbAmount);
            pnFindProduct.Controls.Add(txtProductName);
            pnFindProduct.Controls.Add(nudQuantity);
            pnFindProduct.Controls.Add(lbSelectProduct);
            pnFindProduct.Controls.Add(btnAddProduct);
            pnFindProduct.Location = new Point(5, 261);
            pnFindProduct.Name = "pnFindProduct";
            pnFindProduct.Size = new Size(1200, 60);
            pnFindProduct.TabIndex = 1;
            // 
            // btnRemoveAll
            // 
            btnRemoveAll.CustomizableEdges = customizableEdges19;
            btnRemoveAll.DisabledState.BorderColor = Color.DarkGray;
            btnRemoveAll.DisabledState.CustomBorderColor = Color.DarkGray;
            btnRemoveAll.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnRemoveAll.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnRemoveAll.FillColor = Color.FromArgb(59, 93, 79);
            btnRemoveAll.Font = new Font("Segoe UI", 9F);
            btnRemoveAll.ForeColor = Color.White;
            btnRemoveAll.Location = new Point(965, 3);
            btnRemoveAll.Name = "btnRemoveAll";
            btnRemoveAll.ShadowDecoration.CustomizableEdges = customizableEdges20;
            btnRemoveAll.Size = new Size(161, 53);
            btnRemoveAll.TabIndex = 7;
            btnRemoveAll.Text = "Xoá tất cả";
            btnRemoveAll.Click += btnRemoveAll_Click;
            // 
            // btnDelete
            // 
            btnDelete.CustomizableEdges = customizableEdges21;
            btnDelete.DisabledState.BorderColor = Color.DarkGray;
            btnDelete.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDelete.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDelete.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDelete.FillColor = Color.FromArgb(59, 93, 79);
            btnDelete.Font = new Font("Segoe UI", 9F);
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(797, 4);
            btnDelete.Name = "btnDelete";
            btnDelete.ShadowDecoration.CustomizableEdges = customizableEdges22;
            btnDelete.Size = new Size(161, 53);
            btnDelete.TabIndex = 6;
            btnDelete.Text = "Xoá";
            btnDelete.Click += btnDelete_Click;
            // 
            // lbUnit
            // 
            lbUnit.AutoSize = true;
            lbUnit.ForeColor = Color.FromArgb(59, 93, 79);
            lbUnit.Location = new Point(512, 25);
            lbUnit.Name = "lbUnit";
            lbUnit.Size = new Size(37, 20);
            lbUnit.TabIndex = 4;
            lbUnit.Text = "ĐVT";
            // 
            // lbAmount
            // 
            lbAmount.AutoSize = true;
            lbAmount.ForeColor = Color.FromArgb(59, 93, 79);
            lbAmount.Location = new Point(359, 20);
            lbAmount.Name = "lbAmount";
            lbAmount.Size = new Size(69, 20);
            lbAmount.TabIndex = 2;
            lbAmount.Text = "Số lượng";
            // 
            // txtProductName
            // 
            txtProductName.Location = new Point(101, 15);
            txtProductName.Margin = new Padding(3, 4, 3, 4);
            txtProductName.Name = "txtProductName";
            txtProductName.Size = new Size(223, 27);
            txtProductName.TabIndex = 1;
            txtProductName.Click += txtProductName_Click;
            // 
            // nudQuantity
            // 
            nudQuantity.BackColor = Color.Transparent;
            nudQuantity.CustomizableEdges = customizableEdges23;
            nudQuantity.Font = new Font("Segoe UI", 9F);
            nudQuantity.ForeColor = Color.FromArgb(59, 93, 79);
            nudQuantity.Location = new Point(427, 15);
            nudQuantity.Margin = new Padding(3, 5, 3, 5);
            nudQuantity.Name = "nudQuantity";
            nudQuantity.ShadowDecoration.CustomizableEdges = customizableEdges24;
            nudQuantity.Size = new Size(78, 36);
            nudQuantity.TabIndex = 3;
            nudQuantity.UpDownButtonFillColor = Color.FromArgb(59, 93, 79);
            // 
            // dgvSale
            // 
            dgvSale.AllowUserToAddRows = false;
            dgvSale.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = Color.White;
            dgvSale.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            dgvSale.BackgroundColor = Color.Gainsboro;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle5.ForeColor = Color.White;
            dataGridViewCellStyle5.SelectionBackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            dgvSale.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            dgvSale.ColumnHeadersHeight = 50;
            dgvSale.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.White;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle6.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle6.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            dgvSale.DefaultCellStyle = dataGridViewCellStyle6;
            dgvSale.GridColor = Color.FromArgb(231, 229, 255);
            dgvSale.Location = new Point(624, 327);
            dgvSale.Name = "dgvSale";
            dgvSale.ReadOnly = true;
            dgvSale.RowHeadersVisible = false;
            dgvSale.RowHeadersWidth = 51;
            dgvSale.Size = new Size(581, 528);
            dgvSale.TabIndex = 3;
            dgvSale.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgvSale.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgvSale.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgvSale.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgvSale.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgvSale.ThemeStyle.BackColor = Color.Gainsboro;
            dgvSale.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgvSale.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgvSale.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvSale.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            dgvSale.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgvSale.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgvSale.ThemeStyle.HeaderStyle.Height = 50;
            dgvSale.ThemeStyle.ReadOnly = true;
            dgvSale.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgvSale.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvSale.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            dgvSale.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgvSale.ThemeStyle.RowsStyle.Height = 29;
            dgvSale.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgvSale.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgvSale.CellClick += dgvSale_CellClick;
            // 
            // frmSale
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1232, 865);
            Controls.Add(dgvSale);
            Controls.Add(pnFindProduct);
            Controls.Add(pnInfo);
            Controls.Add(dgvProduct);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            Name = "frmSale";
            StartPosition = FormStartPosition.CenterParent;
            Text = "frmSale";
            Load += frmSale_Load;
            pnButton.ResumeLayout(false);
            gbInvoice.ResumeLayout(false);
            pnPurchase.ResumeLayout(false);
            pnPurchase.PerformLayout();
            pnPaymentMethod.ResumeLayout(false);
            pnPaymentMethod.PerformLayout();
            pnInvoiceInfo.ResumeLayout(false);
            pnInvoiceInfo.PerformLayout();
            gbCustomer.ResumeLayout(false);
            pnCustomer.ResumeLayout(false);
            pnCustomer.PerformLayout();
            fpnBtnCustomer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvProduct).EndInit();
            pnInfo.ResumeLayout(false);
            pnFindProduct.ResumeLayout(false);
            pnFindProduct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudQuantity).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvSale).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Label lbSelectProduct;
        // Replace the declaration and initialization of btnAddProduct and other Guna2Button instances  
        // to ensure they are correctly typed as Guna.UI2.WinForms.Guna2Button instead of System.Windows.Forms.Button.  

        private Guna.UI2.WinForms.Guna2Button btnAddProduct;
        private Label lblUnit;
        private Panel pnlSearch;
        private Guna.UI2.WinForms.Guna2Button btnClear;
        private Guna.UI2.WinForms.Guna2Button btnCreate;
        private Guna.UI2.WinForms.Guna2Button btnConfirm;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private FlowLayoutPanel pnButton;
        private Guna.UI2.WinForms.Guna2GroupBox gbInvoice;
        private Guna.UI2.WinForms.Guna2GroupBox gbCustomer;
        private Guna.UI2.WinForms.Guna2DataGridView dgvProduct;
        private FlowLayoutPanel pnInfo;
        private FlowLayoutPanel fpnBtnCustomer;
        private Panel pnFindProduct;
        private Guna.UI2.WinForms.Guna2NumericUpDown nudQuantity;
        private Panel pnInvoiceInfo;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpDate;
        private TextBox txtEmployeeName;
        private Label lbID;
        private Label lbDate;
        private Label lbEmployee;
        private TextBox txtId;
        private Panel pnCustomer;
        private TextBox txtCustomerName;
        private Label lbCustomerName;
        private Label lbAddress;
        private TextBox txtAddress;
        private TextBox txtPhoneNumber;
        private Label lbPhoneNumber;
        private Panel pnPurchase;
        private TextBox txtTotal;
        private TextBox txtProductQuantity;
        private Label lbProductQuantity;
        private Label lbTotal;
        private Label lbCurrency;
        private Guna.UI2.WinForms.Guna2DataGridView dgvSale;
        private Guna.UI2.WinForms.Guna2Button btnAddCustomer;
        private Label lbVoucherId;
        private ComboBox cbVoucher;
        private TextBox txtProductName;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
        private Label lbUnit;
        private Label lbAmount;
        private Guna.UI2.WinForms.Guna2Button btnRemoveAll;
        private Label lbPaymentMethod;
        private Panel pnPaymentMethod;
        private Guna.UI2.WinForms.Guna2RadioButton rdTransfer;
        private Guna.UI2.WinForms.Guna2RadioButton rdCash;
    }
}