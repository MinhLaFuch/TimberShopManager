﻿namespace timber_shop_manager
{
    partial class frmCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCustomer));
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            txtPhoneNumber = new TextBox();
            txtName = new TextBox();
            txtAddress = new TextBox();
            lbAddress = new Label();
            lbName = new Label();
            lbPhoneNumber = new Label();
            dgvCustomer = new Guna.UI2.WinForms.Guna2DataGridView();
            gbInfo = new Guna.UI2.WinForms.Guna2GroupBox();
            pnInfo = new Panel();
            pnButton = new FlowLayoutPanel();
            btnSave = new Guna.UI2.WinForms.Guna2Button();
            btnCancel = new Guna.UI2.WinForms.Guna2Button();
            btnSearch = new Guna.UI2.WinForms.Guna2Button();
            btnMod = new Guna.UI2.WinForms.Guna2Button();
            gbPurchaseHistory = new Guna.UI2.WinForms.Guna2GroupBox();
            pnPurchase = new Panel();
            panel1 = new Panel();
            dtpTimeTo = new Guna.UI2.WinForms.Guna2DateTimePicker();
            dtpTimeFrom = new Guna.UI2.WinForms.Guna2DateTimePicker();
            pbArrow = new PictureBox();
            lbInvoiceId = new Label();
            txtInvoiceId = new TextBox();
            dgvPurchase = new Guna.UI2.WinForms.Guna2DataGridView();
            btnViewDetail = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)dgvCustomer).BeginInit();
            gbInfo.SuspendLayout();
            pnInfo.SuspendLayout();
            pnButton.SuspendLayout();
            gbPurchaseHistory.SuspendLayout();
            pnPurchase.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbArrow).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvPurchase).BeginInit();
            SuspendLayout();
            // 
            // txtPhoneNumber
            // 
            txtPhoneNumber.BackColor = Color.White;
            txtPhoneNumber.BorderStyle = BorderStyle.None;
            txtPhoneNumber.ForeColor = Color.FromArgb(59, 93, 79);
            txtPhoneNumber.Location = new Point(176, 7);
            txtPhoneNumber.Margin = new Padding(3, 4, 3, 4);
            txtPhoneNumber.Name = "txtPhoneNumber";
            txtPhoneNumber.Size = new Size(373, 20);
            txtPhoneNumber.TabIndex = 1;
            // 
            // txtName
            // 
            txtName.BackColor = Color.White;
            txtName.BorderStyle = BorderStyle.None;
            txtName.ForeColor = Color.FromArgb(59, 93, 79);
            txtName.Location = new Point(176, 51);
            txtName.Margin = new Padding(3, 4, 3, 4);
            txtName.Name = "txtName";
            txtName.Size = new Size(373, 20);
            txtName.TabIndex = 3;
            // 
            // txtAddress
            // 
            txtAddress.BackColor = Color.White;
            txtAddress.BorderStyle = BorderStyle.None;
            txtAddress.ForeColor = Color.FromArgb(59, 93, 79);
            txtAddress.Location = new Point(176, 95);
            txtAddress.Margin = new Padding(3, 4, 3, 4);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(373, 20);
            txtAddress.TabIndex = 5;
            // 
            // lbAddress
            // 
            lbAddress.AutoSize = true;
            lbAddress.ForeColor = Color.FromArgb(59, 93, 79);
            lbAddress.Location = new Point(15, 95);
            lbAddress.Name = "lbAddress";
            lbAddress.Size = new Size(55, 20);
            lbAddress.TabIndex = 4;
            lbAddress.Text = "Địa chỉ";
            // 
            // lbName
            // 
            lbName.AutoSize = true;
            lbName.ForeColor = Color.FromArgb(59, 93, 79);
            lbName.Location = new Point(15, 51);
            lbName.Name = "lbName";
            lbName.Size = new Size(111, 20);
            lbName.TabIndex = 2;
            lbName.Text = "Tên khách hàng";
            // 
            // lbPhoneNumber
            // 
            lbPhoneNumber.AutoSize = true;
            lbPhoneNumber.ForeColor = Color.FromArgb(59, 93, 79);
            lbPhoneNumber.Location = new Point(15, 7);
            lbPhoneNumber.Name = "lbPhoneNumber";
            lbPhoneNumber.Size = new Size(97, 20);
            lbPhoneNumber.TabIndex = 0;
            lbPhoneNumber.Text = "Số điện thoại";
            // 
            // dgvCustomer
            // 
            dgvCustomer.AllowUserToAddRows = false;
            dgvCustomer.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.White;
            dgvCustomer.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgvCustomer.BackgroundColor = Color.Gainsboro;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgvCustomer.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgvCustomer.ColumnHeadersHeight = 50;
            dgvCustomer.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgvCustomer.DefaultCellStyle = dataGridViewCellStyle3;
            dgvCustomer.GridColor = Color.FromArgb(231, 229, 255);
            dgvCustomer.Location = new Point(11, 325);
            dgvCustomer.Name = "dgvCustomer";
            dgvCustomer.ReadOnly = true;
            dgvCustomer.RowHeadersVisible = false;
            dgvCustomer.RowHeadersWidth = 51;
            dgvCustomer.Size = new Size(709, 495);
            dgvCustomer.TabIndex = 4;
            dgvCustomer.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgvCustomer.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgvCustomer.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgvCustomer.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgvCustomer.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgvCustomer.ThemeStyle.BackColor = Color.Gainsboro;
            dgvCustomer.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgvCustomer.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgvCustomer.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvCustomer.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            dgvCustomer.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgvCustomer.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgvCustomer.ThemeStyle.HeaderStyle.Height = 50;
            dgvCustomer.ThemeStyle.ReadOnly = true;
            dgvCustomer.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgvCustomer.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvCustomer.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            dgvCustomer.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgvCustomer.ThemeStyle.RowsStyle.Height = 29;
            dgvCustomer.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgvCustomer.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgvCustomer.CellClick += dgvCustomer_CellClick;
            // 
            // gbInfo
            // 
            gbInfo.Controls.Add(pnInfo);
            gbInfo.CustomBorderColor = Color.FromArgb(59, 93, 79);
            gbInfo.CustomizableEdges = customizableEdges1;
            gbInfo.FillColor = SystemColors.Control;
            gbInfo.Font = new Font("Segoe UI", 9F);
            gbInfo.ForeColor = Color.White;
            gbInfo.Location = new Point(11, 8);
            gbInfo.Name = "gbInfo";
            gbInfo.ShadowDecoration.CustomizableEdges = customizableEdges2;
            gbInfo.Size = new Size(711, 241);
            gbInfo.TabIndex = 0;
            gbInfo.Text = "Thông tin";
            // 
            // pnInfo
            // 
            pnInfo.Controls.Add(txtName);
            pnInfo.Controls.Add(txtAddress);
            pnInfo.Controls.Add(lbAddress);
            pnInfo.Controls.Add(lbName);
            pnInfo.Controls.Add(txtPhoneNumber);
            pnInfo.Controls.Add(lbPhoneNumber);
            pnInfo.Location = new Point(11, 51);
            pnInfo.Name = "pnInfo";
            pnInfo.Size = new Size(634, 124);
            pnInfo.TabIndex = 0;
            // 
            // pnButton
            // 
            pnButton.Controls.Add(btnSave);
            pnButton.Controls.Add(btnCancel);
            pnButton.Controls.Add(btnSearch);
            pnButton.Controls.Add(btnMod);
            pnButton.FlowDirection = FlowDirection.RightToLeft;
            pnButton.Location = new Point(11, 255);
            pnButton.Name = "pnButton";
            pnButton.Size = new Size(709, 65);
            pnButton.TabIndex = 2;
            // 
            // btnSave
            // 
            btnSave.CustomizableEdges = customizableEdges3;
            btnSave.DisabledState.BorderColor = Color.DarkGray;
            btnSave.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSave.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSave.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSave.FillColor = Color.FromArgb(59, 93, 79);
            btnSave.Font = new Font("Segoe UI", 9F);
            btnSave.ForeColor = Color.White;
            btnSave.Location = new Point(568, 3);
            btnSave.Name = "btnSave";
            btnSave.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnSave.Size = new Size(138, 37);
            btnSave.TabIndex = 1;
            btnSave.Text = "Lưu";
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.CustomizableEdges = customizableEdges5;
            btnCancel.DisabledState.BorderColor = Color.DarkGray;
            btnCancel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCancel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCancel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCancel.FillColor = Color.FromArgb(59, 93, 79);
            btnCancel.Font = new Font("Segoe UI", 9F);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(424, 3);
            btnCancel.Name = "btnCancel";
            btnCancel.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnCancel.Size = new Size(138, 37);
            btnCancel.TabIndex = 0;
            btnCancel.Text = "Hủy";
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSearch
            // 
            btnSearch.CustomizableEdges = customizableEdges7;
            btnSearch.DisabledState.BorderColor = Color.DarkGray;
            btnSearch.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSearch.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSearch.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSearch.FillColor = Color.FromArgb(59, 93, 79);
            btnSearch.Font = new Font("Segoe UI", 9F);
            btnSearch.ForeColor = Color.White;
            btnSearch.Location = new Point(280, 3);
            btnSearch.Name = "btnSearch";
            btnSearch.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnSearch.Size = new Size(138, 37);
            btnSearch.TabIndex = 1;
            btnSearch.Text = "Tìm kiếm";
            btnSearch.Click += btnSearch_Click;
            // 
            // btnMod
            // 
            btnMod.CustomizableEdges = customizableEdges9;
            btnMod.DisabledState.BorderColor = Color.DarkGray;
            btnMod.DisabledState.CustomBorderColor = Color.DarkGray;
            btnMod.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnMod.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnMod.FillColor = Color.FromArgb(59, 93, 79);
            btnMod.Font = new Font("Segoe UI", 9F);
            btnMod.ForeColor = Color.White;
            btnMod.Location = new Point(136, 3);
            btnMod.Name = "btnMod";
            btnMod.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnMod.Size = new Size(138, 37);
            btnMod.TabIndex = 0;
            btnMod.Text = "Sửa";
            btnMod.Click += btnMod_Click;
            // 
            // gbPurchaseHistory
            // 
            gbPurchaseHistory.Controls.Add(pnPurchase);
            gbPurchaseHistory.CustomBorderColor = Color.FromArgb(59, 93, 79);
            gbPurchaseHistory.CustomizableEdges = customizableEdges15;
            gbPurchaseHistory.Enabled = false;
            gbPurchaseHistory.FillColor = SystemColors.Control;
            gbPurchaseHistory.Font = new Font("Segoe UI", 9F);
            gbPurchaseHistory.ForeColor = Color.White;
            gbPurchaseHistory.Location = new Point(729, 8);
            gbPurchaseHistory.Name = "gbPurchaseHistory";
            gbPurchaseHistory.ShadowDecoration.CustomizableEdges = customizableEdges16;
            gbPurchaseHistory.Size = new Size(475, 241);
            gbPurchaseHistory.TabIndex = 1;
            gbPurchaseHistory.Text = "Lịch sử thanh toán";
            gbPurchaseHistory.EnabledChanged += gbPurchaseHistory_EnabledChanged;
            // 
            // pnPurchase
            // 
            pnPurchase.Controls.Add(panel1);
            pnPurchase.Controls.Add(lbInvoiceId);
            pnPurchase.Controls.Add(txtInvoiceId);
            pnPurchase.Location = new Point(16, 51);
            pnPurchase.Name = "pnPurchase";
            pnPurchase.Size = new Size(448, 183);
            pnPurchase.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.Controls.Add(dtpTimeTo);
            panel1.Controls.Add(dtpTimeFrom);
            panel1.Controls.Add(pbArrow);
            panel1.Location = new Point(8, 11);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(431, 72);
            panel1.TabIndex = 0;
            // 
            // dtpTimeTo
            // 
            dtpTimeTo.Checked = true;
            dtpTimeTo.CustomFormat = "dd/MM/yyyy";
            dtpTimeTo.CustomizableEdges = customizableEdges11;
            dtpTimeTo.FillColor = Color.FromArgb(59, 93, 79);
            dtpTimeTo.Font = new Font("Segoe UI", 9F);
            dtpTimeTo.Format = DateTimePickerFormat.Custom;
            dtpTimeTo.Location = new Point(240, 12);
            dtpTimeTo.Margin = new Padding(3, 4, 3, 4);
            dtpTimeTo.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpTimeTo.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpTimeTo.Name = "dtpTimeTo";
            dtpTimeTo.ShadowDecoration.CustomizableEdges = customizableEdges12;
            dtpTimeTo.Size = new Size(166, 48);
            dtpTimeTo.TabIndex = 1;
            dtpTimeTo.Value = new DateTime(2025, 4, 29, 22, 40, 11, 296);
            dtpTimeTo.ValueChanged += dtp_ValueChanged;
            // 
            // dtpTimeFrom
            // 
            dtpTimeFrom.Checked = true;
            dtpTimeFrom.CustomFormat = "dd/MM/yyyy";
            dtpTimeFrom.CustomizableEdges = customizableEdges13;
            dtpTimeFrom.FillColor = Color.FromArgb(59, 93, 79);
            dtpTimeFrom.Font = new Font("Segoe UI", 9F);
            dtpTimeFrom.Format = DateTimePickerFormat.Custom;
            dtpTimeFrom.Location = new Point(8, 12);
            dtpTimeFrom.Margin = new Padding(3, 4, 3, 4);
            dtpTimeFrom.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpTimeFrom.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpTimeFrom.Name = "dtpTimeFrom";
            dtpTimeFrom.ShadowDecoration.CustomizableEdges = customizableEdges14;
            dtpTimeFrom.Size = new Size(166, 48);
            dtpTimeFrom.TabIndex = 0;
            dtpTimeFrom.Value = new DateTime(2025, 4, 29, 22, 40, 11, 296);
            dtpTimeFrom.ValueChanged += dtp_ValueChanged;
            // 
            // pbArrow
            // 
            pbArrow.Image = (Image)resources.GetObject("pbArrow.Image");
            pbArrow.Location = new Point(169, 13);
            pbArrow.Name = "pbArrow";
            pbArrow.Size = new Size(81, 47);
            pbArrow.SizeMode = PictureBoxSizeMode.CenterImage;
            pbArrow.TabIndex = 26;
            pbArrow.TabStop = false;
            // 
            // lbInvoiceId
            // 
            lbInvoiceId.AutoSize = true;
            lbInvoiceId.ForeColor = Color.FromArgb(59, 93, 79);
            lbInvoiceId.Location = new Point(16, 104);
            lbInvoiceId.Name = "lbInvoiceId";
            lbInvoiceId.Size = new Size(89, 20);
            lbInvoiceId.TabIndex = 1;
            lbInvoiceId.Text = "Mã hoá đơn";
            // 
            // txtInvoiceId
            // 
            txtInvoiceId.BackColor = Color.White;
            txtInvoiceId.BorderStyle = BorderStyle.None;
            txtInvoiceId.ForeColor = Color.FromArgb(59, 93, 79);
            txtInvoiceId.Location = new Point(177, 104);
            txtInvoiceId.Margin = new Padding(3, 4, 3, 4);
            txtInvoiceId.Name = "txtInvoiceId";
            txtInvoiceId.Size = new Size(237, 20);
            txtInvoiceId.TabIndex = 2;
            txtInvoiceId.TextChanged += txtInvoiceId_TextChanged;
            // 
            // dgvPurchase
            // 
            dgvPurchase.AllowUserToAddRows = false;
            dgvPurchase.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = Color.White;
            dgvPurchase.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            dgvPurchase.BackgroundColor = Color.LightGray;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle5.ForeColor = Color.White;
            dataGridViewCellStyle5.SelectionBackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            dgvPurchase.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            dgvPurchase.ColumnHeadersHeight = 50;
            dgvPurchase.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.White;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle6.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle6.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            dgvPurchase.DefaultCellStyle = dataGridViewCellStyle6;
            dgvPurchase.GridColor = Color.FromArgb(231, 229, 255);
            dgvPurchase.Location = new Point(729, 325);
            dgvPurchase.Name = "dgvPurchase";
            dgvPurchase.ReadOnly = true;
            dgvPurchase.RowHeadersVisible = false;
            dgvPurchase.RowHeadersWidth = 51;
            dgvPurchase.Size = new Size(475, 495);
            dgvPurchase.TabIndex = 5;
            dgvPurchase.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgvPurchase.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgvPurchase.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgvPurchase.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgvPurchase.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgvPurchase.ThemeStyle.BackColor = Color.LightGray;
            dgvPurchase.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgvPurchase.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgvPurchase.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvPurchase.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            dgvPurchase.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgvPurchase.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgvPurchase.ThemeStyle.HeaderStyle.Height = 50;
            dgvPurchase.ThemeStyle.ReadOnly = true;
            dgvPurchase.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgvPurchase.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvPurchase.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            dgvPurchase.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgvPurchase.ThemeStyle.RowsStyle.Height = 29;
            dgvPurchase.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgvPurchase.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgvPurchase.CellClick += dgvPurchase_CellClick;
            // 
            // btnViewDetail
            // 
            btnViewDetail.CustomizableEdges = customizableEdges17;
            btnViewDetail.DisabledState.BorderColor = Color.DarkGray;
            btnViewDetail.DisabledState.CustomBorderColor = Color.DarkGray;
            btnViewDetail.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnViewDetail.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnViewDetail.FillColor = Color.FromArgb(59, 93, 79);
            btnViewDetail.Font = new Font("Segoe UI", 9F);
            btnViewDetail.ForeColor = Color.White;
            btnViewDetail.Location = new Point(1055, 268);
            btnViewDetail.Name = "btnViewDetail";
            btnViewDetail.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnViewDetail.Size = new Size(138, 37);
            btnViewDetail.TabIndex = 3;
            btnViewDetail.Text = "Xem chi tiết";
            btnViewDetail.Click += btnViewDetail_Click;
            // 
            // frmCustomer
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1217, 835);
            Controls.Add(pnButton);
            Controls.Add(dgvPurchase);
            Controls.Add(btnViewDetail);
            Controls.Add(gbPurchaseHistory);
            Controls.Add(gbInfo);
            Controls.Add(dgvCustomer);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            Name = "frmCustomer";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Khách hàng";
            Load += frmCustomer_Load;
            ((System.ComponentModel.ISupportInitialize)dgvCustomer).EndInit();
            gbInfo.ResumeLayout(false);
            pnInfo.ResumeLayout(false);
            pnInfo.PerformLayout();
            pnButton.ResumeLayout(false);
            gbPurchaseHistory.ResumeLayout(false);
            pnPurchase.ResumeLayout(false);
            pnPurchase.PerformLayout();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pbArrow).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvPurchase).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private TextBox txtPhoneNumber;
        private TextBox txtName;
        private TextBox txtAddress;
        private Label lbAddress;
        private Label lbName;
        private Label lbPhoneNumber;
        private Guna.UI2.WinForms.Guna2DataGridView dgvCustomer;
        private Guna.UI2.WinForms.Guna2GroupBox gbInfo;
        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2Button btnMod;
        private Guna.UI2.WinForms.Guna2GroupBox gbPurchaseHistory;
        private Guna.UI2.WinForms.Guna2DataGridView dgvPurchase;
        private FlowLayoutPanel pnButton;
        private Panel pnInfo;
        private Panel pnPurchase;
        private Label lbInvoiceId;
        private TextBox txtInvoiceId;
        private Panel panel1;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpTimeTo;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpTimeFrom;
        private Guna.UI2.WinForms.Guna2Button btnViewDetail;
        private PictureBox pbArrow;
        private Guna.UI2.WinForms.Guna2Button btnSearch;
    }
}