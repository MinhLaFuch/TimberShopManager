﻿namespace timber_shop_manager.GUI
{
    partial class frmImport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmImport));
            gbInvoiceInfor = new Guna.UI2.WinForms.Guna2GroupBox();
            txtEmployeeId = new TextBox();
            txtInvoiceId = new TextBox();
            lbImportTime = new Guna.UI2.WinForms.Guna2HtmlLabel();
            dtpImportTime = new Guna.UI2.WinForms.Guna2DateTimePicker();
            lbEmployeeId = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lbInvoiceid = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            txtSupplierPhoneNumber = new TextBox();
            txtSupplierName = new TextBox();
            txtSupplierid = new TextBox();
            lbSupplierPhoneNumber = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lbSupplierName = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lbSupplierId = new Guna.UI2.WinForms.Guna2HtmlLabel();
            btnNew = new Guna.UI2.WinForms.Guna2Button();
            btnCancel = new Guna.UI2.WinForms.Guna2Button();
            btbClear = new Guna.UI2.WinForms.Guna2Button();
            guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            cbCalUnit = new ComboBox();
            cbCategory = new ComboBox();
            lbPercentant = new Label();
            nudTax = new Guna.UI2.WinForms.Guna2NumericUpDown();
            lbTax = new Label();
            txtDescription = new RichTextBox();
            lbDescription = new Label();
            txtProductId = new TextBox();
            txtProductName = new TextBox();
            lbVND = new Label();
            lbCategory = new Label();
            lbQuantity = new Label();
            nudQuantity = new Guna.UI2.WinForms.Guna2NumericUpDown();
            lbWarranty = new Label();
            lbProductId = new Label();
            lbMonth = new Label();
            nudWarranty = new Guna.UI2.WinForms.Guna2NumericUpDown();
            lbPriceQuotation = new Label();
            lbProductName = new Label();
            nudPriceQuotation = new Guna.UI2.WinForms.Guna2NumericUpDown();
            dgv = new Guna.UI2.WinForms.Guna2DataGridView();
            btnSave = new Guna.UI2.WinForms.Guna2Button();
            btnNewProduct = new Guna.UI2.WinForms.Guna2Button();
            lbPaymentMethod = new Label();
            pnPaymentMethod = new Panel();
            rdTransfer = new Guna.UI2.WinForms.Guna2RadioButton();
            rdCash = new Guna.UI2.WinForms.Guna2RadioButton();
            flowLayoutPanel1 = new FlowLayoutPanel();
            gbInvoiceInfor.SuspendLayout();
            guna2GroupBox2.SuspendLayout();
            guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudTax).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudQuantity).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudWarranty).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudPriceQuotation).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgv).BeginInit();
            pnPaymentMethod.SuspendLayout();
            flowLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // gbInvoiceInfor
            // 
            gbInvoiceInfor.Controls.Add(txtEmployeeId);
            gbInvoiceInfor.Controls.Add(txtInvoiceId);
            gbInvoiceInfor.Controls.Add(lbImportTime);
            gbInvoiceInfor.Controls.Add(dtpImportTime);
            gbInvoiceInfor.Controls.Add(lbEmployeeId);
            gbInvoiceInfor.Controls.Add(lbInvoiceid);
            gbInvoiceInfor.CustomBorderColor = Color.FromArgb(59, 93, 79);
            gbInvoiceInfor.CustomizableEdges = customizableEdges3;
            gbInvoiceInfor.Enabled = false;
            gbInvoiceInfor.FillColor = SystemColors.Control;
            gbInvoiceInfor.Font = new Font("Segoe UI", 9F);
            gbInvoiceInfor.ForeColor = Color.White;
            gbInvoiceInfor.Location = new Point(14, 16);
            gbInvoiceInfor.Margin = new Padding(3, 4, 3, 4);
            gbInvoiceInfor.Name = "gbInvoiceInfor";
            gbInvoiceInfor.ShadowDecoration.CustomizableEdges = customizableEdges4;
            gbInvoiceInfor.Size = new Size(553, 225);
            gbInvoiceInfor.TabIndex = 0;
            gbInvoiceInfor.Text = "Thông tin hoá đơn nhập";
            // 
            // txtEmployeeId
            // 
            txtEmployeeId.BorderStyle = BorderStyle.None;
            txtEmployeeId.ForeColor = Color.FromArgb(59, 93, 79);
            txtEmployeeId.Location = new Point(118, 115);
            txtEmployeeId.Margin = new Padding(3, 4, 3, 4);
            txtEmployeeId.Name = "txtEmployeeId";
            txtEmployeeId.Size = new Size(431, 20);
            txtEmployeeId.TabIndex = 3;
            // 
            // txtInvoiceId
            // 
            txtInvoiceId.BorderStyle = BorderStyle.None;
            txtInvoiceId.ForeColor = Color.FromArgb(59, 93, 79);
            txtInvoiceId.Location = new Point(118, 76);
            txtInvoiceId.Margin = new Padding(3, 4, 3, 4);
            txtInvoiceId.Name = "txtInvoiceId";
            txtInvoiceId.Size = new Size(431, 20);
            txtInvoiceId.TabIndex = 1;
            // 
            // lbImportTime
            // 
            lbImportTime.BackColor = Color.Transparent;
            lbImportTime.ForeColor = Color.FromArgb(59, 93, 79);
            lbImportTime.Location = new Point(18, 175);
            lbImportTime.Margin = new Padding(3, 4, 3, 4);
            lbImportTime.Name = "lbImportTime";
            lbImportTime.Size = new Size(65, 22);
            lbImportTime.TabIndex = 4;
            lbImportTime.Text = "Thời gian";
            // 
            // dtpImportTime
            // 
            dtpImportTime.Checked = true;
            dtpImportTime.CustomFormat = "dd/MM/yyyy";
            dtpImportTime.CustomizableEdges = customizableEdges1;
            dtpImportTime.FillColor = Color.FromArgb(59, 93, 79);
            dtpImportTime.Font = new Font("Segoe UI", 9F);
            dtpImportTime.ForeColor = Color.White;
            dtpImportTime.Format = DateTimePickerFormat.Custom;
            dtpImportTime.Location = new Point(118, 161);
            dtpImportTime.Margin = new Padding(3, 4, 3, 4);
            dtpImportTime.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpImportTime.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpImportTime.Name = "dtpImportTime";
            dtpImportTime.ShadowDecoration.CustomizableEdges = customizableEdges2;
            dtpImportTime.Size = new Size(137, 48);
            dtpImportTime.TabIndex = 5;
            dtpImportTime.Value = new DateTime(2025, 4, 30, 1, 4, 17, 503);
            // 
            // lbEmployeeId
            // 
            lbEmployeeId.BackColor = Color.Transparent;
            lbEmployeeId.ForeColor = Color.FromArgb(59, 93, 79);
            lbEmployeeId.Location = new Point(18, 124);
            lbEmployeeId.Margin = new Padding(3, 4, 3, 4);
            lbEmployeeId.Name = "lbEmployeeId";
            lbEmployeeId.Size = new Size(91, 22);
            lbEmployeeId.TabIndex = 2;
            lbEmployeeId.Text = "Mã nhân viên";
            // 
            // lbInvoiceid
            // 
            lbInvoiceid.BackColor = Color.Transparent;
            lbInvoiceid.ForeColor = Color.FromArgb(59, 93, 79);
            lbInvoiceid.Location = new Point(18, 76);
            lbInvoiceid.Margin = new Padding(3, 4, 3, 4);
            lbInvoiceid.Name = "lbInvoiceid";
            lbInvoiceid.Size = new Size(83, 22);
            lbInvoiceid.TabIndex = 0;
            lbInvoiceid.Text = "Mã hoá đơn";
            // 
            // guna2GroupBox2
            // 
            guna2GroupBox2.Controls.Add(txtSupplierPhoneNumber);
            guna2GroupBox2.Controls.Add(txtSupplierName);
            guna2GroupBox2.Controls.Add(txtSupplierid);
            guna2GroupBox2.Controls.Add(lbSupplierPhoneNumber);
            guna2GroupBox2.Controls.Add(lbSupplierName);
            guna2GroupBox2.Controls.Add(lbSupplierId);
            guna2GroupBox2.CustomBorderColor = Color.FromArgb(59, 93, 79);
            guna2GroupBox2.CustomizableEdges = customizableEdges5;
            guna2GroupBox2.FillColor = SystemColors.Control;
            guna2GroupBox2.Font = new Font("Segoe UI", 9F);
            guna2GroupBox2.ForeColor = Color.White;
            guna2GroupBox2.Location = new Point(574, 16);
            guna2GroupBox2.Margin = new Padding(3, 4, 3, 4);
            guna2GroupBox2.Name = "guna2GroupBox2";
            guna2GroupBox2.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2GroupBox2.Size = new Size(603, 225);
            guna2GroupBox2.TabIndex = 1;
            guna2GroupBox2.Text = "Nhà cung cấp";
            // 
            // txtSupplierPhoneNumber
            // 
            txtSupplierPhoneNumber.BorderStyle = BorderStyle.None;
            txtSupplierPhoneNumber.ForeColor = Color.FromArgb(59, 93, 79);
            txtSupplierPhoneNumber.Location = new Point(77, 155);
            txtSupplierPhoneNumber.Margin = new Padding(3, 4, 3, 4);
            txtSupplierPhoneNumber.Name = "txtSupplierPhoneNumber";
            txtSupplierPhoneNumber.Size = new Size(431, 20);
            txtSupplierPhoneNumber.TabIndex = 5;
            txtSupplierPhoneNumber.TextChanged += txtSupplierPhoneNumber_TextChanged;
            // 
            // txtSupplierName
            // 
            txtSupplierName.BorderStyle = BorderStyle.None;
            txtSupplierName.ForeColor = Color.FromArgb(59, 93, 79);
            txtSupplierName.Location = new Point(77, 116);
            txtSupplierName.Margin = new Padding(3, 4, 3, 4);
            txtSupplierName.Name = "txtSupplierName";
            txtSupplierName.Size = new Size(431, 20);
            txtSupplierName.TabIndex = 3;
            // 
            // txtSupplierid
            // 
            txtSupplierid.BorderStyle = BorderStyle.None;
            txtSupplierid.Enabled = false;
            txtSupplierid.ForeColor = Color.FromArgb(59, 93, 79);
            txtSupplierid.Location = new Point(77, 76);
            txtSupplierid.Margin = new Padding(3, 4, 3, 4);
            txtSupplierid.Name = "txtSupplierid";
            txtSupplierid.Size = new Size(431, 20);
            txtSupplierid.TabIndex = 1;
            // 
            // lbSupplierPhoneNumber
            // 
            lbSupplierPhoneNumber.BackColor = Color.Transparent;
            lbSupplierPhoneNumber.ForeColor = Color.FromArgb(59, 93, 79);
            lbSupplierPhoneNumber.Location = new Point(23, 161);
            lbSupplierPhoneNumber.Margin = new Padding(3, 4, 3, 4);
            lbSupplierPhoneNumber.Name = "lbSupplierPhoneNumber";
            lbSupplierPhoneNumber.Size = new Size(30, 22);
            lbSupplierPhoneNumber.TabIndex = 4;
            lbSupplierPhoneNumber.Text = "SĐT";
            // 
            // lbSupplierName
            // 
            lbSupplierName.BackColor = Color.Transparent;
            lbSupplierName.ForeColor = Color.FromArgb(59, 93, 79);
            lbSupplierName.Location = new Point(23, 115);
            lbSupplierName.Margin = new Padding(3, 4, 3, 4);
            lbSupplierName.Name = "lbSupplierName";
            lbSupplierName.Size = new Size(27, 22);
            lbSupplierName.TabIndex = 2;
            lbSupplierName.Text = "Tên";
            // 
            // lbSupplierId
            // 
            lbSupplierId.BackColor = Color.Transparent;
            lbSupplierId.ForeColor = Color.FromArgb(59, 93, 79);
            lbSupplierId.Location = new Point(23, 76);
            lbSupplierId.Margin = new Padding(3, 4, 3, 4);
            lbSupplierId.Name = "lbSupplierId";
            lbSupplierId.Size = new Size(24, 22);
            lbSupplierId.TabIndex = 0;
            lbSupplierId.Text = "Mã";
            // 
            // btnNew
            // 
            btnNew.CustomizableEdges = customizableEdges7;
            btnNew.DisabledState.BorderColor = Color.DarkGray;
            btnNew.DisabledState.CustomBorderColor = Color.DarkGray;
            btnNew.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnNew.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnNew.FillColor = Color.FromArgb(59, 93, 79);
            btnNew.Font = new Font("Segoe UI", 9F);
            btnNew.ForeColor = Color.White;
            btnNew.Location = new Point(16, 4);
            btnNew.Margin = new Padding(3, 4, 3, 4);
            btnNew.Name = "btnNew";
            btnNew.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnNew.Size = new Size(134, 57);
            btnNew.TabIndex = 2;
            btnNew.Text = "Thêm";
            btnNew.Click += btnNew_Click;
            // 
            // btnCancel
            // 
            btnCancel.CustomizableEdges = customizableEdges9;
            btnCancel.DisabledState.BorderColor = Color.DarkGray;
            btnCancel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCancel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCancel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCancel.FillColor = Color.FromArgb(59, 93, 79);
            btnCancel.Font = new Font("Segoe UI", 9F);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(576, 4);
            btnCancel.Margin = new Padding(3, 4, 3, 4);
            btnCancel.Name = "btnCancel";
            btnCancel.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnCancel.Size = new Size(134, 57);
            btnCancel.TabIndex = 3;
            btnCancel.Text = "Huỷ";
            btnCancel.Click += btnCancel_Click;
            // 
            // btbClear
            // 
            btbClear.CustomizableEdges = customizableEdges11;
            btbClear.DisabledState.BorderColor = Color.DarkGray;
            btbClear.DisabledState.CustomBorderColor = Color.DarkGray;
            btbClear.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btbClear.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btbClear.FillColor = Color.FromArgb(59, 93, 79);
            btbClear.Font = new Font("Segoe UI", 9F);
            btbClear.ForeColor = Color.White;
            btbClear.Location = new Point(296, 4);
            btbClear.Margin = new Padding(3, 4, 3, 4);
            btbClear.Name = "btbClear";
            btbClear.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btbClear.Size = new Size(134, 57);
            btbClear.TabIndex = 0;
            btbClear.Text = "Xoá sạch";
            btbClear.Click += btnClear_Click;
            // 
            // guna2GroupBox1
            // 
            guna2GroupBox1.Controls.Add(cbCalUnit);
            guna2GroupBox1.Controls.Add(cbCategory);
            guna2GroupBox1.Controls.Add(lbPercentant);
            guna2GroupBox1.Controls.Add(nudTax);
            guna2GroupBox1.Controls.Add(lbTax);
            guna2GroupBox1.Controls.Add(txtDescription);
            guna2GroupBox1.Controls.Add(lbDescription);
            guna2GroupBox1.Controls.Add(txtProductId);
            guna2GroupBox1.Controls.Add(txtProductName);
            guna2GroupBox1.Controls.Add(lbVND);
            guna2GroupBox1.Controls.Add(lbCategory);
            guna2GroupBox1.Controls.Add(lbQuantity);
            guna2GroupBox1.Controls.Add(nudQuantity);
            guna2GroupBox1.Controls.Add(lbWarranty);
            guna2GroupBox1.Controls.Add(lbProductId);
            guna2GroupBox1.Controls.Add(lbMonth);
            guna2GroupBox1.Controls.Add(nudWarranty);
            guna2GroupBox1.Controls.Add(lbPriceQuotation);
            guna2GroupBox1.Controls.Add(lbProductName);
            guna2GroupBox1.Controls.Add(nudPriceQuotation);
            guna2GroupBox1.CustomBorderColor = Color.FromArgb(59, 93, 79);
            guna2GroupBox1.CustomizableEdges = customizableEdges21;
            guna2GroupBox1.FillColor = SystemColors.Control;
            guna2GroupBox1.Font = new Font("Segoe UI", 9F);
            guna2GroupBox1.ForeColor = Color.White;
            guna2GroupBox1.Location = new Point(14, 315);
            guna2GroupBox1.Margin = new Padding(3, 4, 3, 4);
            guna2GroupBox1.Name = "guna2GroupBox1";
            guna2GroupBox1.ShadowDecoration.CustomizableEdges = customizableEdges22;
            guna2GroupBox1.Size = new Size(553, 444);
            guna2GroupBox1.TabIndex = 5;
            guna2GroupBox1.Text = "Sản phẩm";
            // 
            // cbCalUnit
            // 
            cbCalUnit.ForeColor = Color.FromArgb(59, 93, 79);
            cbCalUnit.FormattingEnabled = true;
            cbCalUnit.Location = new Point(299, 265);
            cbCalUnit.Margin = new Padding(3, 4, 3, 4);
            cbCalUnit.Name = "cbCalUnit";
            cbCalUnit.Size = new Size(138, 28);
            cbCalUnit.TabIndex = 16;
            // 
            // cbCategory
            // 
            cbCategory.ForeColor = Color.FromArgb(59, 93, 79);
            cbCategory.FormattingEnabled = true;
            cbCategory.Location = new Point(141, 175);
            cbCategory.Margin = new Padding(3, 4, 3, 4);
            cbCategory.Name = "cbCategory";
            cbCategory.Size = new Size(345, 28);
            cbCategory.TabIndex = 10;
            // 
            // lbPercentant
            // 
            lbPercentant.AutoSize = true;
            lbPercentant.ForeColor = Color.FromArgb(59, 93, 79);
            lbPercentant.Location = new Point(493, 139);
            lbPercentant.Name = "lbPercentant";
            lbPercentant.Size = new Size(21, 20);
            lbPercentant.TabIndex = 8;
            lbPercentant.Text = "%";
            // 
            // nudTax
            // 
            nudTax.BackColor = Color.Transparent;
            nudTax.CustomizableEdges = customizableEdges13;
            nudTax.Font = new Font("Segoe UI", 9F);
            nudTax.ForeColor = Color.FromArgb(59, 93, 79);
            nudTax.Location = new Point(430, 135);
            nudTax.Margin = new Padding(3, 5, 3, 5);
            nudTax.Name = "nudTax";
            nudTax.ShadowDecoration.CustomizableEdges = customizableEdges14;
            nudTax.Size = new Size(56, 33);
            nudTax.TabIndex = 7;
            nudTax.UpDownButtonFillColor = Color.FromArgb(59, 93, 79);
            // 
            // lbTax
            // 
            lbTax.AutoSize = true;
            lbTax.ForeColor = Color.FromArgb(59, 93, 79);
            lbTax.Location = new Point(385, 139);
            lbTax.Name = "lbTax";
            lbTax.Size = new Size(41, 20);
            lbTax.TabIndex = 6;
            lbTax.Text = "Thuế";
            // 
            // txtDescription
            // 
            txtDescription.BackColor = Color.White;
            txtDescription.BorderStyle = BorderStyle.None;
            txtDescription.ForeColor = Color.FromArgb(59, 93, 79);
            txtDescription.Location = new Point(129, 305);
            txtDescription.Name = "txtDescription";
            txtDescription.ScrollBars = RichTextBoxScrollBars.ForcedHorizontal;
            txtDescription.Size = new Size(357, 124);
            txtDescription.TabIndex = 18;
            txtDescription.Text = "";
            // 
            // lbDescription
            // 
            lbDescription.AutoSize = true;
            lbDescription.ForeColor = Color.FromArgb(59, 93, 79);
            lbDescription.Location = new Point(14, 305);
            lbDescription.Name = "lbDescription";
            lbDescription.Size = new Size(48, 20);
            lbDescription.TabIndex = 17;
            lbDescription.Text = "Mô tả";
            // 
            // txtProductId
            // 
            txtProductId.BackColor = Color.White;
            txtProductId.BorderStyle = BorderStyle.None;
            txtProductId.ForeColor = Color.FromArgb(59, 93, 79);
            txtProductId.Location = new Point(141, 69);
            txtProductId.Name = "txtProductId";
            txtProductId.Size = new Size(345, 20);
            txtProductId.TabIndex = 1;
            // 
            // txtProductName
            // 
            txtProductName.BackColor = Color.White;
            txtProductName.BorderStyle = BorderStyle.None;
            txtProductName.ForeColor = Color.FromArgb(59, 93, 79);
            txtProductName.Location = new Point(141, 107);
            txtProductName.Name = "txtProductName";
            txtProductName.Size = new Size(345, 20);
            txtProductName.TabIndex = 2;
            txtProductName.TextChanged += txtProductName_TextChanged;
            // 
            // lbVND
            // 
            lbVND.BackColor = Color.Transparent;
            lbVND.ForeColor = Color.FromArgb(59, 93, 79);
            lbVND.Location = new Point(299, 133);
            lbVND.Name = "lbVND";
            lbVND.Size = new Size(62, 31);
            lbVND.TabIndex = 5;
            lbVND.Text = "VND";
            lbVND.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbCategory
            // 
            lbCategory.AutoSize = true;
            lbCategory.ForeColor = Color.FromArgb(59, 93, 79);
            lbCategory.Location = new Point(14, 173);
            lbCategory.Name = "lbCategory";
            lbCategory.Size = new Size(37, 20);
            lbCategory.TabIndex = 9;
            lbCategory.Text = "Loại";
            // 
            // lbQuantity
            // 
            lbQuantity.AutoSize = true;
            lbQuantity.ForeColor = Color.FromArgb(59, 93, 79);
            lbQuantity.Location = new Point(14, 269);
            lbQuantity.Name = "lbQuantity";
            lbQuantity.Size = new Size(69, 20);
            lbQuantity.TabIndex = 14;
            lbQuantity.Text = "Số lượng";
            // 
            // nudQuantity
            // 
            nudQuantity.BackColor = Color.Transparent;
            nudQuantity.CustomizableEdges = customizableEdges15;
            nudQuantity.Font = new Font("Segoe UI", 9F);
            nudQuantity.ForeColor = Color.FromArgb(59, 93, 79);
            nudQuantity.Location = new Point(141, 265);
            nudQuantity.Margin = new Padding(3, 5, 3, 5);
            nudQuantity.Name = "nudQuantity";
            nudQuantity.ShadowDecoration.CustomizableEdges = customizableEdges16;
            nudQuantity.Size = new Size(142, 33);
            nudQuantity.TabIndex = 15;
            nudQuantity.UpDownButtonFillColor = Color.FromArgb(59, 93, 79);
            // 
            // lbWarranty
            // 
            lbWarranty.AutoSize = true;
            lbWarranty.ForeColor = Color.FromArgb(59, 93, 79);
            lbWarranty.Location = new Point(14, 229);
            lbWarranty.Name = "lbWarranty";
            lbWarranty.Size = new Size(102, 20);
            lbWarranty.TabIndex = 11;
            lbWarranty.Text = "Hạn bảo hành";
            // 
            // lbProductId
            // 
            lbProductId.AutoSize = true;
            lbProductId.ForeColor = Color.FromArgb(59, 93, 79);
            lbProductId.Location = new Point(14, 69);
            lbProductId.Name = "lbProductId";
            lbProductId.Size = new Size(30, 20);
            lbProductId.TabIndex = 0;
            lbProductId.Text = "Mã";
            // 
            // lbMonth
            // 
            lbMonth.BackColor = Color.Transparent;
            lbMonth.ForeColor = Color.FromArgb(59, 93, 79);
            lbMonth.Location = new Point(299, 225);
            lbMonth.Name = "lbMonth";
            lbMonth.Size = new Size(62, 31);
            lbMonth.TabIndex = 13;
            lbMonth.Text = "tháng";
            lbMonth.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // nudWarranty
            // 
            nudWarranty.BackColor = Color.Transparent;
            nudWarranty.CustomizableEdges = customizableEdges17;
            nudWarranty.Font = new Font("Segoe UI", 9F);
            nudWarranty.ForeColor = Color.FromArgb(59, 93, 79);
            nudWarranty.Location = new Point(141, 223);
            nudWarranty.Margin = new Padding(3, 5, 3, 5);
            nudWarranty.Name = "nudWarranty";
            nudWarranty.ShadowDecoration.CustomizableEdges = customizableEdges18;
            nudWarranty.Size = new Size(142, 33);
            nudWarranty.TabIndex = 12;
            nudWarranty.UpDownButtonFillColor = Color.FromArgb(59, 93, 79);
            // 
            // lbPriceQuotation
            // 
            lbPriceQuotation.AutoSize = true;
            lbPriceQuotation.ForeColor = Color.FromArgb(59, 93, 79);
            lbPriceQuotation.Location = new Point(14, 133);
            lbPriceQuotation.Name = "lbPriceQuotation";
            lbPriceQuotation.Size = new Size(62, 20);
            lbPriceQuotation.TabIndex = 3;
            lbPriceQuotation.Text = "Đơn giá";
            // 
            // lbProductName
            // 
            lbProductName.AutoSize = true;
            lbProductName.ForeColor = Color.FromArgb(59, 93, 79);
            lbProductName.Location = new Point(14, 107);
            lbProductName.Name = "lbProductName";
            lbProductName.Size = new Size(32, 20);
            lbProductName.TabIndex = 1;
            lbProductName.Text = "Tên";
            // 
            // nudPriceQuotation
            // 
            nudPriceQuotation.BackColor = Color.Transparent;
            nudPriceQuotation.CustomizableEdges = customizableEdges19;
            nudPriceQuotation.Font = new Font("Segoe UI", 9F);
            nudPriceQuotation.ForeColor = Color.FromArgb(59, 93, 79);
            nudPriceQuotation.Location = new Point(141, 133);
            nudPriceQuotation.Margin = new Padding(3, 5, 3, 5);
            nudPriceQuotation.Name = "nudPriceQuotation";
            nudPriceQuotation.ShadowDecoration.CustomizableEdges = customizableEdges20;
            nudPriceQuotation.Size = new Size(142, 33);
            nudPriceQuotation.TabIndex = 4;
            nudPriceQuotation.UpDownButtonFillColor = Color.FromArgb(59, 93, 79);
            // 
            // dgv
            // 
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.White;
            dgv.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgv.BackgroundColor = SystemColors.Control;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgv.ColumnHeadersHeight = 50;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgv.DefaultCellStyle = dataGridViewCellStyle3;
            dgv.GridColor = Color.FromArgb(231, 229, 255);
            dgv.Location = new Point(574, 315);
            dgv.Margin = new Padding(3, 4, 3, 4);
            dgv.Name = "dgv";
            dgv.ReadOnly = true;
            dgv.RowHeadersVisible = false;
            dgv.RowHeadersWidth = 51;
            dgv.RowTemplate.Height = 25;
            dgv.Size = new Size(603, 444);
            dgv.TabIndex = 6;
            dgv.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv.ThemeStyle.BackColor = SystemColors.Control;
            dgv.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            dgv.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv.ThemeStyle.HeaderStyle.Height = 50;
            dgv.ThemeStyle.ReadOnly = true;
            dgv.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            dgv.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgv.ThemeStyle.RowsStyle.Height = 25;
            dgv.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // btnSave
            // 
            btnSave.CustomizableEdges = customizableEdges23;
            btnSave.DisabledState.BorderColor = Color.DarkGray;
            btnSave.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSave.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSave.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSave.FillColor = Color.FromArgb(59, 93, 79);
            btnSave.Font = new Font("Segoe UI", 9F);
            btnSave.ForeColor = Color.White;
            btnSave.Location = new Point(436, 4);
            btnSave.Margin = new Padding(3, 4, 3, 4);
            btnSave.Name = "btnSave";
            btnSave.ShadowDecoration.CustomizableEdges = customizableEdges24;
            btnSave.Size = new Size(134, 57);
            btnSave.TabIndex = 1;
            btnSave.Text = "Lưu";
            btnSave.Click += btnSave_Click;
            // 
            // btnNewProduct
            // 
            btnNewProduct.CustomizableEdges = customizableEdges25;
            btnNewProduct.DisabledState.BorderColor = Color.DarkGray;
            btnNewProduct.DisabledState.CustomBorderColor = Color.DarkGray;
            btnNewProduct.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnNewProduct.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnNewProduct.FillColor = Color.FromArgb(59, 93, 79);
            btnNewProduct.Font = new Font("Segoe UI", 9F);
            btnNewProduct.ForeColor = Color.White;
            btnNewProduct.Location = new Point(156, 4);
            btnNewProduct.Margin = new Padding(3, 4, 3, 4);
            btnNewProduct.Name = "btnNewProduct";
            btnNewProduct.ShadowDecoration.CustomizableEdges = customizableEdges26;
            btnNewProduct.Size = new Size(134, 57);
            btnNewProduct.TabIndex = 4;
            btnNewProduct.Text = "Thêm sản phẩm";
            btnNewProduct.Click += btnNewProduct_Click;
            // 
            // lbPaymentMethod
            // 
            lbPaymentMethod.AutoSize = true;
            lbPaymentMethod.BackColor = Color.Transparent;
            lbPaymentMethod.ForeColor = Color.FromArgb(59, 93, 79);
            lbPaymentMethod.Location = new Point(859, 261);
            lbPaymentMethod.Name = "lbPaymentMethod";
            lbPaymentMethod.Size = new Size(83, 20);
            lbPaymentMethod.TabIndex = 3;
            lbPaymentMethod.Text = "Thanh toán";
            // 
            // pnPaymentMethod
            // 
            pnPaymentMethod.Controls.Add(rdTransfer);
            pnPaymentMethod.Controls.Add(rdCash);
            pnPaymentMethod.Location = new Point(961, 249);
            pnPaymentMethod.Margin = new Padding(3, 4, 3, 4);
            pnPaymentMethod.Name = "pnPaymentMethod";
            pnPaymentMethod.Size = new Size(216, 41);
            pnPaymentMethod.TabIndex = 4;
            // 
            // rdTransfer
            // 
            rdTransfer.AutoSize = true;
            rdTransfer.CheckedState.BorderColor = Color.FromArgb(94, 148, 255);
            rdTransfer.CheckedState.BorderThickness = 0;
            rdTransfer.CheckedState.FillColor = Color.FromArgb(94, 148, 255);
            rdTransfer.CheckedState.InnerColor = Color.White;
            rdTransfer.CheckedState.InnerOffset = -4;
            rdTransfer.FlatStyle = FlatStyle.Flat;
            rdTransfer.ForeColor = Color.Black;
            rdTransfer.Location = new Point(94, 7);
            rdTransfer.Margin = new Padding(3, 4, 3, 4);
            rdTransfer.Name = "rdTransfer";
            rdTransfer.Size = new Size(121, 24);
            rdTransfer.TabIndex = 1;
            rdTransfer.Text = "Chuyển khoản";
            rdTransfer.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            rdTransfer.UncheckedState.BorderThickness = 2;
            rdTransfer.UncheckedState.FillColor = Color.Transparent;
            rdTransfer.UncheckedState.InnerColor = Color.Transparent;
            // 
            // rdCash
            // 
            rdCash.AutoSize = true;
            rdCash.Checked = true;
            rdCash.CheckedState.BorderColor = Color.FromArgb(94, 148, 255);
            rdCash.CheckedState.BorderThickness = 0;
            rdCash.CheckedState.FillColor = Color.FromArgb(94, 148, 255);
            rdCash.CheckedState.InnerColor = Color.White;
            rdCash.CheckedState.InnerOffset = -4;
            rdCash.FlatStyle = FlatStyle.Flat;
            rdCash.ForeColor = Color.FromArgb(59, 93, 79);
            rdCash.Location = new Point(3, 7);
            rdCash.Margin = new Padding(3, 4, 3, 4);
            rdCash.Name = "rdCash";
            rdCash.Size = new Size(87, 24);
            rdCash.TabIndex = 0;
            rdCash.TabStop = true;
            rdCash.Text = "Tiền mặt";
            rdCash.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            rdCash.UncheckedState.BorderThickness = 2;
            rdCash.UncheckedState.FillColor = Color.Transparent;
            rdCash.UncheckedState.InnerColor = Color.Transparent;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(btnCancel);
            flowLayoutPanel1.Controls.Add(btnSave);
            flowLayoutPanel1.Controls.Add(btbClear);
            flowLayoutPanel1.Controls.Add(btnNewProduct);
            flowLayoutPanel1.Controls.Add(btnNew);
            flowLayoutPanel1.FlowDirection = FlowDirection.RightToLeft;
            flowLayoutPanel1.Location = new Point(132, 248);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(713, 60);
            flowLayoutPanel1.TabIndex = 2;
            // 
            // frmImport
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1191, 775);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(lbPaymentMethod);
            Controls.Add(pnPaymentMethod);
            Controls.Add(dgv);
            Controls.Add(guna2GroupBox1);
            Controls.Add(guna2GroupBox2);
            Controls.Add(gbInvoiceInfor);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            Name = "frmImport";
            Text = "frmImport";
            Load += frmImport_Load;
            gbInvoiceInfor.ResumeLayout(false);
            gbInvoiceInfor.PerformLayout();
            guna2GroupBox2.ResumeLayout(false);
            guna2GroupBox2.PerformLayout();
            guna2GroupBox1.ResumeLayout(false);
            guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudTax).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudQuantity).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudWarranty).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudPriceQuotation).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgv).EndInit();
            pnPaymentMethod.ResumeLayout(false);
            pnPaymentMethod.PerformLayout();
            flowLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2GroupBox gbInvoiceInfor;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbEmployeeId;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbInvoiceid;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private TextBox txtEmployeeId;
        private TextBox txtInvoiceId;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbImportTime;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpImportTime;
        private Guna.UI2.WinForms.Guna2Button btnNew;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private TextBox txtSupplierPhoneNumber;
        private TextBox txtSupplierName;
        private TextBox txtSupplierid;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbSupplierPhoneNumber;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbSupplierName;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbSupplierId;
        private Guna.UI2.WinForms.Guna2Button btbClear;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2DataGridView dgv;
        private TextBox txtProductId;
        private TextBox txtProductName;
        private Label lbVND;
        private Label lbCategory;
        private Label lbQuantity;
        private Guna.UI2.WinForms.Guna2NumericUpDown nudQuantity;
        private Label lbWarranty;
        private Label lbProductId;
        private Label lbMonth;
        private Guna.UI2.WinForms.Guna2NumericUpDown nudWarranty;
        private Label lbPriceQuotation;
        private Label lbProductName;
        private Guna.UI2.WinForms.Guna2NumericUpDown nudPriceQuotation;
        private RichTextBox txtDescription;
        private Label lbDescription;
        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2NumericUpDown nudTax;
        private Label lbTax;
        private Guna.UI2.WinForms.Guna2Button btnNewProduct;
        private Label lbPercentant;
        private ComboBox cbCategory;
        private ComboBox cbCalUnit;
        private Label lbPaymentMethod;
        private Panel pnPaymentMethod;
        private Guna.UI2.WinForms.Guna2RadioButton rdTransfer;
        private Guna.UI2.WinForms.Guna2RadioButton rdCash;
        private FlowLayoutPanel flowLayoutPanel1;
    }
}