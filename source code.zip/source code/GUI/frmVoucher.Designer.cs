﻿namespace timber_shop_manager.objects
{
    partial class frmVoucher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVoucher));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            grInfo = new Guna.UI2.WinForms.Guna2GroupBox();
            lbStatus = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lbContent = new Guna.UI2.WinForms.Guna2HtmlLabel();
            txtName = new Guna.UI2.WinForms.Guna2TextBox();
            txtId = new Guna.UI2.WinForms.Guna2TextBox();
            pnTime = new Guna.UI2.WinForms.Guna2Panel();
            pictureBox1 = new PictureBox();
            dtpTo = new Guna.UI2.WinForms.Guna2DateTimePicker();
            dtpFrom = new Guna.UI2.WinForms.Guna2DateTimePicker();
            pnUnit = new Guna.UI2.WinForms.Guna2Panel();
            rdAmount = new Guna.UI2.WinForms.Guna2RadioButton();
            rdPercentant = new Guna.UI2.WinForms.Guna2RadioButton();
            nudDiscount = new Guna.UI2.WinForms.Guna2NumericUpDown();
            lbDiscount = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lbName = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lbId = new Guna.UI2.WinForms.Guna2HtmlLabel();
            txtContent = new Guna.UI2.WinForms.Guna2TextBox();
            dgv = new Guna.UI2.WinForms.Guna2DataGridView();
            btnCancel = new Guna.UI2.WinForms.Guna2Button();
            btnSave = new Guna.UI2.WinForms.Guna2Button();
            btnAdd = new Guna.UI2.WinForms.Guna2Button();
            pnControl = new FlowLayoutPanel();
            grInfo.SuspendLayout();
            pnTime.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnUnit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudDiscount).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgv).BeginInit();
            pnControl.SuspendLayout();
            SuspendLayout();
            // 
            // grInfo
            // 
            grInfo.Controls.Add(lbStatus);
            grInfo.Controls.Add(lbContent);
            grInfo.Controls.Add(txtName);
            grInfo.Controls.Add(txtId);
            grInfo.Controls.Add(pnTime);
            grInfo.Controls.Add(pnUnit);
            grInfo.Controls.Add(nudDiscount);
            grInfo.Controls.Add(lbDiscount);
            grInfo.Controls.Add(lbName);
            grInfo.Controls.Add(lbId);
            grInfo.Controls.Add(txtContent);
            grInfo.CustomBorderColor = Color.FromArgb(59, 93, 79);
            grInfo.CustomizableEdges = customizableEdges17;
            grInfo.FillColor = SystemColors.Control;
            grInfo.Font = new Font("Segoe UI", 9F);
            grInfo.ForeColor = Color.White;
            grInfo.Location = new Point(14, 16);
            grInfo.Margin = new Padding(3, 4, 3, 4);
            grInfo.Name = "grInfo";
            grInfo.ShadowDecoration.CustomizableEdges = customizableEdges18;
            grInfo.Size = new Size(1206, 247);
            grInfo.TabIndex = 0;
            grInfo.Text = "Thông tin";
            // 
            // lbStatus
            // 
            lbStatus.BackColor = Color.Transparent;
            lbStatus.ForeColor = Color.FromArgb(59, 93, 79);
            lbStatus.Location = new Point(59, 105);
            lbStatus.Margin = new Padding(3, 4, 3, 4);
            lbStatus.Name = "lbStatus";
            lbStatus.Size = new Size(41, 22);
            lbStatus.TabIndex = 2;
            lbStatus.Text = "status";
            // 
            // lbContent
            // 
            lbContent.BackColor = Color.Transparent;
            lbContent.Enabled = false;
            lbContent.ForeColor = Color.FromArgb(59, 93, 79);
            lbContent.Location = new Point(474, 143);
            lbContent.Margin = new Padding(3, 4, 3, 4);
            lbContent.Name = "lbContent";
            lbContent.Size = new Size(65, 22);
            lbContent.TabIndex = 9;
            lbContent.Text = "Nội dung";
            // 
            // txtName
            // 
            txtName.BackColor = SystemColors.Control;
            txtName.CustomizableEdges = customizableEdges1;
            txtName.DefaultText = "";
            txtName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Font = new Font("Segoe UI", 9F);
            txtName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Location = new Point(57, 136);
            txtName.Margin = new Padding(3, 5, 3, 5);
            txtName.Name = "txtName";
            txtName.PlaceholderText = "";
            txtName.SelectedText = "";
            txtName.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtName.Size = new Size(399, 33);
            txtName.TabIndex = 4;
            // 
            // txtId
            // 
            txtId.BackColor = SystemColors.Control;
            txtId.CustomizableEdges = customizableEdges3;
            txtId.DefaultText = "";
            txtId.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtId.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtId.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtId.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtId.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtId.Font = new Font("Segoe UI", 9F);
            txtId.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtId.Location = new Point(57, 71);
            txtId.Margin = new Padding(3, 5, 3, 5);
            txtId.Name = "txtId";
            txtId.PlaceholderText = "";
            txtId.SelectedText = "";
            txtId.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtId.Size = new Size(399, 33);
            txtId.TabIndex = 1;
            txtId.TextChanged += txtId_TextChanged;
            txtId.KeyPress += txtId_KeyPress;
            // 
            // pnTime
            // 
            pnTime.Controls.Add(pictureBox1);
            pnTime.Controls.Add(dtpTo);
            pnTime.Controls.Add(dtpFrom);
            pnTime.CustomizableEdges = customizableEdges9;
            pnTime.Location = new Point(547, 71);
            pnTime.Margin = new Padding(3, 4, 3, 4);
            pnTime.Name = "pnTime";
            pnTime.ShadowDecoration.CustomizableEdges = customizableEdges10;
            pnTime.Size = new Size(374, 44);
            pnTime.TabIndex = 8;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(150, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(81, 47);
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 27;
            pictureBox1.TabStop = false;
            // 
            // dtpTo
            // 
            dtpTo.Checked = true;
            dtpTo.CustomFormat = "dd/MM/yyyy";
            dtpTo.CustomizableEdges = customizableEdges5;
            dtpTo.FillColor = Color.FromArgb(59, 93, 79);
            dtpTo.Font = new Font("Segoe UI", 9F);
            dtpTo.Format = DateTimePickerFormat.Custom;
            dtpTo.Location = new Point(227, 0);
            dtpTo.Margin = new Padding(3, 4, 3, 4);
            dtpTo.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpTo.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpTo.Name = "dtpTo";
            dtpTo.ShadowDecoration.CustomizableEdges = customizableEdges6;
            dtpTo.Size = new Size(144, 40);
            dtpTo.TabIndex = 1;
            dtpTo.Value = new DateTime(2025, 4, 22, 15, 11, 25, 18);
            // 
            // dtpFrom
            // 
            dtpFrom.Checked = true;
            dtpFrom.CustomFormat = "dd/MM/yyyy";
            dtpFrom.CustomizableEdges = customizableEdges7;
            dtpFrom.FillColor = Color.FromArgb(59, 93, 79);
            dtpFrom.Font = new Font("Segoe UI", 9F);
            dtpFrom.Format = DateTimePickerFormat.Custom;
            dtpFrom.Location = new Point(0, 0);
            dtpFrom.Margin = new Padding(3, 4, 3, 4);
            dtpFrom.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpFrom.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpFrom.Name = "dtpFrom";
            dtpFrom.ShadowDecoration.CustomizableEdges = customizableEdges8;
            dtpFrom.Size = new Size(144, 40);
            dtpFrom.TabIndex = 0;
            dtpFrom.Value = new DateTime(2025, 4, 22, 15, 12, 21, 585);
            dtpFrom.ValueChanged += dtpFrom_ValueChanged;
            // 
            // pnUnit
            // 
            pnUnit.Controls.Add(rdAmount);
            pnUnit.Controls.Add(rdPercentant);
            pnUnit.CustomizableEdges = customizableEdges11;
            pnUnit.Location = new Point(203, 187);
            pnUnit.Margin = new Padding(3, 4, 3, 4);
            pnUnit.Name = "pnUnit";
            pnUnit.ShadowDecoration.CustomizableEdges = customizableEdges12;
            pnUnit.Size = new Size(138, 36);
            pnUnit.TabIndex = 7;
            // 
            // rdAmount
            // 
            rdAmount.AutoSize = true;
            rdAmount.CheckedState.BorderColor = Color.FromArgb(94, 148, 255);
            rdAmount.CheckedState.BorderThickness = 0;
            rdAmount.CheckedState.FillColor = Color.FromArgb(94, 148, 255);
            rdAmount.CheckedState.InnerColor = Color.White;
            rdAmount.CheckedState.InnerOffset = -4;
            rdAmount.FlatStyle = FlatStyle.Flat;
            rdAmount.ForeColor = Color.FromArgb(59, 93, 79);
            rdAmount.Location = new Point(79, 7);
            rdAmount.Margin = new Padding(3, 4, 3, 4);
            rdAmount.Name = "rdAmount";
            rdAmount.Size = new Size(60, 24);
            rdAmount.TabIndex = 1;
            rdAmount.Text = "VND";
            rdAmount.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            rdAmount.UncheckedState.BorderThickness = 2;
            rdAmount.UncheckedState.FillColor = Color.Transparent;
            rdAmount.UncheckedState.InnerColor = Color.Transparent;
            rdAmount.CheckedChanged += rdAmount_CheckedChanged;
            // 
            // rdPercentant
            // 
            rdPercentant.AutoSize = true;
            rdPercentant.Checked = true;
            rdPercentant.CheckedState.BorderColor = Color.FromArgb(94, 148, 255);
            rdPercentant.CheckedState.BorderThickness = 0;
            rdPercentant.CheckedState.FillColor = Color.FromArgb(94, 148, 255);
            rdPercentant.CheckedState.InnerColor = Color.White;
            rdPercentant.CheckedState.InnerOffset = -4;
            rdPercentant.FlatStyle = FlatStyle.Flat;
            rdPercentant.ForeColor = Color.FromArgb(59, 93, 79);
            rdPercentant.Location = new Point(3, 7);
            rdPercentant.Margin = new Padding(3, 4, 3, 4);
            rdPercentant.Name = "rdPercentant";
            rdPercentant.Size = new Size(41, 24);
            rdPercentant.TabIndex = 0;
            rdPercentant.TabStop = true;
            rdPercentant.Text = "%";
            rdPercentant.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            rdPercentant.UncheckedState.BorderThickness = 2;
            rdPercentant.UncheckedState.FillColor = Color.Transparent;
            rdPercentant.UncheckedState.InnerColor = Color.Transparent;
            rdPercentant.CheckedChanged += rdPercentant_CheckedChanged;
            // 
            // nudDiscount
            // 
            nudDiscount.BackColor = Color.Transparent;
            nudDiscount.CustomizableEdges = customizableEdges13;
            nudDiscount.Font = new Font("Segoe UI", 9F);
            nudDiscount.ForeColor = Color.FromArgb(59, 93, 79);
            nudDiscount.Location = new Point(57, 187);
            nudDiscount.Margin = new Padding(3, 5, 3, 5);
            nudDiscount.Name = "nudDiscount";
            nudDiscount.ShadowDecoration.CustomizableEdges = customizableEdges14;
            nudDiscount.Size = new Size(96, 36);
            nudDiscount.TabIndex = 6;
            nudDiscount.UpDownButtonFillColor = Color.FromArgb(59, 93, 79);
            // 
            // lbDiscount
            // 
            lbDiscount.BackColor = Color.Transparent;
            lbDiscount.Enabled = false;
            lbDiscount.ForeColor = Color.FromArgb(59, 93, 79);
            lbDiscount.Location = new Point(15, 195);
            lbDiscount.Margin = new Padding(3, 4, 3, 4);
            lbDiscount.Name = "lbDiscount";
            lbDiscount.Size = new Size(38, 22);
            lbDiscount.TabIndex = 5;
            lbDiscount.Text = "Giảm";
            // 
            // lbName
            // 
            lbName.BackColor = Color.Transparent;
            lbName.Enabled = false;
            lbName.ForeColor = Color.FromArgb(59, 93, 79);
            lbName.Location = new Point(15, 143);
            lbName.Margin = new Padding(3, 4, 3, 4);
            lbName.Name = "lbName";
            lbName.Size = new Size(27, 22);
            lbName.TabIndex = 3;
            lbName.Text = "Tên";
            // 
            // lbId
            // 
            lbId.BackColor = Color.Transparent;
            lbId.Enabled = false;
            lbId.ForeColor = Color.FromArgb(59, 93, 79);
            lbId.Location = new Point(15, 80);
            lbId.Margin = new Padding(3, 4, 3, 4);
            lbId.Name = "lbId";
            lbId.Size = new Size(24, 22);
            lbId.TabIndex = 0;
            lbId.Text = "Mã";
            // 
            // txtContent
            // 
            txtContent.BackColor = SystemColors.Control;
            txtContent.CustomizableEdges = customizableEdges15;
            txtContent.DefaultText = "";
            txtContent.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtContent.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtContent.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtContent.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtContent.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtContent.Font = new Font("Segoe UI", 9F);
            txtContent.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtContent.Location = new Point(547, 148);
            txtContent.Margin = new Padding(3, 5, 3, 5);
            txtContent.Multiline = true;
            txtContent.Name = "txtContent";
            txtContent.PlaceholderText = "";
            txtContent.SelectedText = "";
            txtContent.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtContent.Size = new Size(336, 87);
            txtContent.TabIndex = 10;
            // 
            // dgv
            // 
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.White;
            dgv.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgv.BackgroundColor = Color.Gainsboro;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgv.ColumnHeadersHeight = 50;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgv.DefaultCellStyle = dataGridViewCellStyle3;
            dgv.GridColor = Color.FromArgb(231, 229, 255);
            dgv.Location = new Point(14, 335);
            dgv.Margin = new Padding(3, 4, 3, 4);
            dgv.Name = "dgv";
            dgv.ReadOnly = true;
            dgv.RowHeadersVisible = false;
            dgv.RowHeadersWidth = 51;
            dgv.RowTemplate.Height = 25;
            dgv.Size = new Size(1220, 528);
            dgv.TabIndex = 2;
            dgv.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv.ThemeStyle.BackColor = Color.Gainsboro;
            dgv.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            dgv.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv.ThemeStyle.HeaderStyle.Height = 50;
            dgv.ThemeStyle.ReadOnly = true;
            dgv.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            dgv.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgv.ThemeStyle.RowsStyle.Height = 25;
            dgv.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgv.CellFormatting += dgv_CellFormatting;
            // 
            // btnCancel
            // 
            btnCancel.CustomizableEdges = customizableEdges19;
            btnCancel.DisabledState.BorderColor = Color.DarkGray;
            btnCancel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCancel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCancel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCancel.FillColor = Color.FromArgb(59, 93, 79);
            btnCancel.Font = new Font("Segoe UI", 9F);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(473, 4);
            btnCancel.Margin = new Padding(3, 4, 3, 4);
            btnCancel.Name = "btnCancel";
            btnCancel.ShadowDecoration.CustomizableEdges = customizableEdges20;
            btnCancel.Size = new Size(176, 53);
            btnCancel.TabIndex = 0;
            btnCancel.Text = "Hủy";
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.CustomizableEdges = customizableEdges21;
            btnSave.DisabledState.BorderColor = Color.DarkGray;
            btnSave.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSave.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSave.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSave.FillColor = Color.FromArgb(59, 93, 79);
            btnSave.Font = new Font("Segoe UI", 9F);
            btnSave.ForeColor = Color.White;
            btnSave.Location = new Point(291, 4);
            btnSave.Margin = new Padding(3, 4, 3, 4);
            btnSave.Name = "btnSave";
            btnSave.ShadowDecoration.CustomizableEdges = customizableEdges22;
            btnSave.Size = new Size(176, 53);
            btnSave.TabIndex = 1;
            btnSave.Text = "Lưu";
            btnSave.Click += btnSave_Click;
            // 
            // btnAdd
            // 
            btnAdd.CustomizableEdges = customizableEdges23;
            btnAdd.DisabledState.BorderColor = Color.DarkGray;
            btnAdd.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAdd.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAdd.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAdd.FillColor = Color.FromArgb(59, 93, 79);
            btnAdd.Font = new Font("Segoe UI", 9F);
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(109, 4);
            btnAdd.Margin = new Padding(3, 4, 3, 4);
            btnAdd.Name = "btnAdd";
            btnAdd.ShadowDecoration.CustomizableEdges = customizableEdges24;
            btnAdd.Size = new Size(176, 53);
            btnAdd.TabIndex = 2;
            btnAdd.Text = "Thêm";
            btnAdd.Click += btnAdd_Click;
            // 
            // pnControl
            // 
            pnControl.Controls.Add(btnCancel);
            pnControl.Controls.Add(btnSave);
            pnControl.Controls.Add(btnAdd);
            pnControl.FlowDirection = FlowDirection.RightToLeft;
            pnControl.Location = new Point(567, 270);
            pnControl.Name = "pnControl";
            pnControl.Size = new Size(652, 64);
            pnControl.TabIndex = 1;
            // 
            // frmVoucher
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1232, 865);
            Controls.Add(pnControl);
            Controls.Add(dgv);
            Controls.Add(grInfo);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            Name = "frmVoucher";
            Text = "frmVoucher";
            Load += frmVoucher_Load;
            grInfo.ResumeLayout(false);
            grInfo.PerformLayout();
            pnTime.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnUnit.ResumeLayout(false);
            pnUnit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudDiscount).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgv).EndInit();
            pnControl.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2GroupBox grInfo;
        private Guna.UI2.WinForms.Guna2TextBox txtContent;
        private Guna.UI2.WinForms.Guna2DataGridView dgv;
        private Guna.UI2.WinForms.Guna2Button btnAdd;
        private Guna.UI2.WinForms.Guna2Panel pnTime;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpFrom;
        private Guna.UI2.WinForms.Guna2Panel pnUnit;
        private Guna.UI2.WinForms.Guna2RadioButton rdAmount;
        private Guna.UI2.WinForms.Guna2RadioButton rdPercentant;
        private Guna.UI2.WinForms.Guna2NumericUpDown nudDiscount;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbDiscount;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbName;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbId;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2TextBox txtName;
        private Guna.UI2.WinForms.Guna2TextBox txtId;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpTo;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbContent;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbStatus;
        private FlowLayoutPanel pnControl;
        private PictureBox pictureBox1;
    }
}