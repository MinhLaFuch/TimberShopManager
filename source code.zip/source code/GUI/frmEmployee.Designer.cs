﻿namespace timber_shop_manager
{
    partial class frmEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEmployee));
            btnCancel = new Guna.UI2.WinForms.Guna2Button();
            btnSave = new Guna.UI2.WinForms.Guna2Button();
            btnMod = new Guna.UI2.WinForms.Guna2Button();
            btnDel = new Guna.UI2.WinForms.Guna2Button();
            btnSearch = new Guna.UI2.WinForms.Guna2Button();
            btnViewAttendance = new Guna.UI2.WinForms.Guna2Button();
            btnAdd = new Guna.UI2.WinForms.Guna2Button();
            dgv = new Guna.UI2.WinForms.Guna2DataGridView();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            gbInfo = new Guna.UI2.WinForms.Guna2GroupBox();
            flowLayoutPanel1 = new FlowLayoutPanel();
            pnInfor = new Panel();
            lbName = new Label();
            txtName = new TextBox();
            txtIden = new TextBox();
            txtId = new TextBox();
            cbRole = new Guna.UI2.WinForms.Guna2ComboBox();
            lbPhoneNumber = new Label();
            dtpBirthDay = new Guna.UI2.WinForms.Guna2DateTimePicker();
            lbCurrency = new Label();
            txtPhoneNumber = new TextBox();
            txtSalary = new TextBox();
            lbIden = new Label();
            lbSalary = new Label();
            lbId = new Label();
            lbAdress = new Label();
            txtAddress = new TextBox();
            lbBirthday = new Label();
            lbRole = new Label();
            ((System.ComponentModel.ISupportInitialize)dgv).BeginInit();
            gbInfo.SuspendLayout();
            flowLayoutPanel1.SuspendLayout();
            pnInfor.SuspendLayout();
            SuspendLayout();
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.FromArgb(59, 93, 79);
            btnCancel.CustomizableEdges = customizableEdges1;
            btnCancel.DisabledState.BorderColor = Color.DarkGray;
            btnCancel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCancel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCancel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCancel.FillColor = Color.FromArgb(59, 93, 79);
            btnCancel.Font = new Font("Segoe UI", 9F);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(665, 3);
            btnCancel.Name = "btnCancel";
            btnCancel.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnCancel.Size = new Size(101, 53);
            btnCancel.TabIndex = 1;
            btnCancel.Text = "Hủy";
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.BackColor = Color.FromArgb(59, 93, 79);
            btnSave.CustomizableEdges = customizableEdges3;
            btnSave.DisabledState.BorderColor = Color.DarkGray;
            btnSave.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSave.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSave.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSave.FillColor = Color.FromArgb(59, 93, 79);
            btnSave.Font = new Font("Segoe UI", 9F);
            btnSave.ForeColor = Color.White;
            btnSave.Location = new Point(558, 3);
            btnSave.Name = "btnSave";
            btnSave.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnSave.Size = new Size(101, 53);
            btnSave.TabIndex = 0;
            btnSave.Text = "Lưu";
            btnSave.Click += btnSave_Click;
            // 
            // btnMod
            // 
            btnMod.BackColor = Color.FromArgb(59, 93, 79);
            btnMod.CustomizableEdges = customizableEdges5;
            btnMod.DisabledState.BorderColor = Color.DarkGray;
            btnMod.DisabledState.CustomBorderColor = Color.DarkGray;
            btnMod.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnMod.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnMod.FillColor = Color.FromArgb(59, 93, 79);
            btnMod.Font = new Font("Segoe UI", 9F);
            btnMod.ForeColor = Color.White;
            btnMod.Location = new Point(130, 3);
            btnMod.Name = "btnMod";
            btnMod.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnMod.Size = new Size(101, 53);
            btnMod.TabIndex = 2;
            btnMod.Text = "Sửa";
            btnMod.Click += btnMod_Click;
            // 
            // btnDel
            // 
            btnDel.BackColor = Color.FromArgb(59, 93, 79);
            btnDel.CustomizableEdges = customizableEdges7;
            btnDel.DisabledState.BorderColor = Color.DarkGray;
            btnDel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDel.FillColor = Color.FromArgb(59, 93, 79);
            btnDel.Font = new Font("Segoe UI", 9F);
            btnDel.ForeColor = Color.White;
            btnDel.Location = new Point(237, 3);
            btnDel.Name = "btnDel";
            btnDel.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnDel.Size = new Size(101, 53);
            btnDel.TabIndex = 1;
            btnDel.Text = "Xóa";
            btnDel.Click += btnDel_Click;
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.FromArgb(59, 93, 79);
            btnSearch.CustomizableEdges = customizableEdges9;
            btnSearch.DisabledState.BorderColor = Color.DarkGray;
            btnSearch.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSearch.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSearch.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSearch.FillColor = Color.FromArgb(59, 93, 79);
            btnSearch.Font = new Font("Segoe UI", 9F);
            btnSearch.ForeColor = Color.White;
            btnSearch.Location = new Point(451, 3);
            btnSearch.Name = "btnSearch";
            btnSearch.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnSearch.Size = new Size(101, 53);
            btnSearch.TabIndex = 4;
            btnSearch.Text = "Tìm kiếm";
            btnSearch.Click += btnSearch_Click;
            // 
            // btnViewAttendance
            // 
            btnViewAttendance.BackColor = Color.FromArgb(59, 93, 79);
            btnViewAttendance.CustomizableEdges = customizableEdges11;
            btnViewAttendance.DisabledState.BorderColor = Color.DarkGray;
            btnViewAttendance.DisabledState.CustomBorderColor = Color.DarkGray;
            btnViewAttendance.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnViewAttendance.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnViewAttendance.FillColor = Color.FromArgb(59, 93, 79);
            btnViewAttendance.Font = new Font("Segoe UI", 9F);
            btnViewAttendance.ForeColor = Color.White;
            btnViewAttendance.Location = new Point(344, 3);
            btnViewAttendance.Name = "btnViewAttendance";
            btnViewAttendance.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnViewAttendance.Size = new Size(101, 53);
            btnViewAttendance.TabIndex = 3;
            btnViewAttendance.Text = "Xem chấm công";
            btnViewAttendance.Click += btnViewAttendance_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(59, 93, 79);
            btnAdd.CustomizableEdges = customizableEdges13;
            btnAdd.DisabledState.BorderColor = Color.DarkGray;
            btnAdd.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAdd.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAdd.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAdd.FillColor = Color.FromArgb(59, 93, 79);
            btnAdd.Font = new Font("Segoe UI", 9F);
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(23, 3);
            btnAdd.Name = "btnAdd";
            btnAdd.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btnAdd.Size = new Size(101, 53);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "Thêm";
            btnAdd.Click += btnAdd_Click;
            // 
            // dgv
            // 
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.White;
            dgv.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgv.BackgroundColor = Color.Gainsboro;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgv.ColumnHeadersHeight = 50;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgv.DefaultCellStyle = dataGridViewCellStyle3;
            dgv.GridColor = Color.FromArgb(231, 229, 255);
            dgv.Location = new Point(11, 289);
            dgv.Name = "dgv";
            dgv.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = SystemColors.Control;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dgv.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dgv.RowHeadersVisible = false;
            dgv.RowHeadersWidth = 51;
            dgv.Size = new Size(1182, 503);
            dgv.TabIndex = 1;
            dgv.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv.ThemeStyle.BackColor = Color.Gainsboro;
            dgv.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgv.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            dgv.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv.ThemeStyle.HeaderStyle.Height = 50;
            dgv.ThemeStyle.ReadOnly = true;
            dgv.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            dgv.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgv.ThemeStyle.RowsStyle.Height = 29;
            dgv.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgv.CellClick += dgv_CellClick;
            // 
            // gbInfo
            // 
            gbInfo.Controls.Add(flowLayoutPanel1);
            gbInfo.Controls.Add(pnInfor);
            gbInfo.CustomBorderColor = Color.FromArgb(59, 93, 79);
            gbInfo.CustomizableEdges = customizableEdges19;
            gbInfo.FillColor = SystemColors.Control;
            gbInfo.Font = new Font("Segoe UI", 9F);
            gbInfo.ForeColor = Color.White;
            gbInfo.Location = new Point(11, -3);
            gbInfo.Name = "gbInfo";
            gbInfo.ShadowDecoration.CustomizableEdges = customizableEdges20;
            gbInfo.Size = new Size(1182, 285);
            gbInfo.TabIndex = 0;
            gbInfo.Text = "Thông tin";
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(btnCancel);
            flowLayoutPanel1.Controls.Add(btnSave);
            flowLayoutPanel1.Controls.Add(btnSearch);
            flowLayoutPanel1.Controls.Add(btnViewAttendance);
            flowLayoutPanel1.Controls.Add(btnDel);
            flowLayoutPanel1.Controls.Add(btnMod);
            flowLayoutPanel1.Controls.Add(btnAdd);
            flowLayoutPanel1.Location = new Point(400, 221);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.RightToLeft = RightToLeft.Yes;
            flowLayoutPanel1.Size = new Size(769, 65);
            flowLayoutPanel1.TabIndex = 1;
            // 
            // pnInfor
            // 
            pnInfor.Controls.Add(lbName);
            pnInfor.Controls.Add(txtName);
            pnInfor.Controls.Add(txtIden);
            pnInfor.Controls.Add(txtId);
            pnInfor.Controls.Add(cbRole);
            pnInfor.Controls.Add(lbPhoneNumber);
            pnInfor.Controls.Add(dtpBirthDay);
            pnInfor.Controls.Add(lbCurrency);
            pnInfor.Controls.Add(txtPhoneNumber);
            pnInfor.Controls.Add(txtSalary);
            pnInfor.Controls.Add(lbIden);
            pnInfor.Controls.Add(lbSalary);
            pnInfor.Controls.Add(lbId);
            pnInfor.Controls.Add(lbAdress);
            pnInfor.Controls.Add(txtAddress);
            pnInfor.Controls.Add(lbBirthday);
            pnInfor.Controls.Add(lbRole);
            pnInfor.Location = new Point(21, 53);
            pnInfor.Name = "pnInfor";
            pnInfor.Size = new Size(1150, 163);
            pnInfor.TabIndex = 0;
            // 
            // lbName
            // 
            lbName.AutoSize = true;
            lbName.ForeColor = Color.FromArgb(59, 93, 79);
            lbName.Location = new Point(16, 53);
            lbName.Name = "lbName";
            lbName.Size = new Size(121, 20);
            lbName.TabIndex = 2;
            lbName.Text = "Họ tên nhân viên";
            // 
            // txtName
            // 
            txtName.BackColor = Color.White;
            txtName.BorderStyle = BorderStyle.None;
            txtName.ForeColor = Color.FromArgb(59, 93, 79);
            txtName.Location = new Point(163, 45);
            txtName.Name = "txtName";
            txtName.Size = new Size(231, 20);
            txtName.TabIndex = 3;
            txtName.KeyPress += txtName_KeyPress;
            // 
            // txtIden
            // 
            txtIden.BackColor = Color.White;
            txtIden.BorderStyle = BorderStyle.None;
            txtIden.ForeColor = Color.FromArgb(59, 93, 79);
            txtIden.Location = new Point(163, 88);
            txtIden.Name = "txtIden";
            txtIden.Size = new Size(231, 20);
            txtIden.TabIndex = 5;
            txtIden.KeyPress += txtIden_KeyPress;
            // 
            // txtId
            // 
            txtId.BackColor = Color.White;
            txtId.BorderStyle = BorderStyle.None;
            txtId.ForeColor = Color.FromArgb(59, 93, 79);
            txtId.Location = new Point(163, 4);
            txtId.Name = "txtId";
            txtId.Size = new Size(231, 20);
            txtId.TabIndex = 1;
            // 
            // cbRole
            // 
            cbRole.BackColor = Color.Transparent;
            cbRole.CustomizableEdges = customizableEdges15;
            cbRole.DrawMode = DrawMode.OwnerDrawFixed;
            cbRole.DropDownStyle = ComboBoxStyle.DropDownList;
            cbRole.FocusedColor = Color.FromArgb(94, 148, 255);
            cbRole.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbRole.Font = new Font("Segoe UI", 10F);
            cbRole.ForeColor = Color.FromArgb(59, 93, 79);
            cbRole.ItemHeight = 30;
            cbRole.Items.AddRange(new object[] { "Quản lý cửa hàng", "Quản trị viên", "Nhân viên bán hàng", "Nhân viên kế toán" });
            cbRole.Location = new Point(515, 80);
            cbRole.Name = "cbRole";
            cbRole.ShadowDecoration.CustomizableEdges = customizableEdges16;
            cbRole.Size = new Size(324, 36);
            cbRole.TabIndex = 13;
            // 
            // lbPhoneNumber
            // 
            lbPhoneNumber.AutoSize = true;
            lbPhoneNumber.ForeColor = Color.FromArgb(59, 93, 79);
            lbPhoneNumber.Location = new Point(16, 133);
            lbPhoneNumber.Name = "lbPhoneNumber";
            lbPhoneNumber.Size = new Size(97, 20);
            lbPhoneNumber.TabIndex = 6;
            lbPhoneNumber.Text = "Số điện thoại";
            // 
            // dtpBirthDay
            // 
            dtpBirthDay.BackColor = SystemColors.ControlDark;
            dtpBirthDay.Checked = true;
            dtpBirthDay.CustomFormat = "dd/MM/yyyy";
            dtpBirthDay.CustomizableEdges = customizableEdges17;
            dtpBirthDay.FillColor = Color.FromArgb(59, 93, 79);
            dtpBirthDay.Font = new Font("Segoe UI", 9F);
            dtpBirthDay.ForeColor = Color.White;
            dtpBirthDay.Format = DateTimePickerFormat.Custom;
            dtpBirthDay.Location = new Point(515, 43);
            dtpBirthDay.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpBirthDay.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpBirthDay.Name = "dtpBirthDay";
            dtpBirthDay.ShadowDecoration.CustomizableEdges = customizableEdges18;
            dtpBirthDay.ShowUpDown = true;
            dtpBirthDay.Size = new Size(225, 32);
            dtpBirthDay.TabIndex = 11;
            dtpBirthDay.Value = new DateTime(2025, 4, 14, 10, 47, 29, 149);
            // 
            // lbCurrency
            // 
            lbCurrency.AutoSize = true;
            lbCurrency.ForeColor = Color.FromArgb(59, 93, 79);
            lbCurrency.Location = new Point(717, 133);
            lbCurrency.Name = "lbCurrency";
            lbCurrency.Size = new Size(122, 20);
            lbCurrency.TabIndex = 16;
            lbCurrency.Text = "VND/ Ngày công";
            // 
            // txtPhoneNumber
            // 
            txtPhoneNumber.BackColor = Color.White;
            txtPhoneNumber.BorderStyle = BorderStyle.None;
            txtPhoneNumber.ForeColor = Color.FromArgb(59, 93, 79);
            txtPhoneNumber.Location = new Point(163, 131);
            txtPhoneNumber.Name = "txtPhoneNumber";
            txtPhoneNumber.Size = new Size(231, 20);
            txtPhoneNumber.TabIndex = 7;
            txtPhoneNumber.KeyPress += txtPhoneNumber_KeyPress;
            // 
            // txtSalary
            // 
            txtSalary.BackColor = Color.White;
            txtSalary.BorderStyle = BorderStyle.None;
            txtSalary.ForeColor = Color.FromArgb(59, 93, 79);
            txtSalary.Location = new Point(515, 131);
            txtSalary.Name = "txtSalary";
            txtSalary.Size = new Size(187, 20);
            txtSalary.TabIndex = 15;
            txtSalary.KeyPress += txtSalary_KeyPress;
            // 
            // lbIden
            // 
            lbIden.AutoSize = true;
            lbIden.ForeColor = Color.FromArgb(59, 93, 79);
            lbIden.Location = new Point(16, 95);
            lbIden.Name = "lbIden";
            lbIden.Size = new Size(68, 20);
            lbIden.TabIndex = 4;
            lbIden.Text = "Số CCCD";
            // 
            // lbSalary
            // 
            lbSalary.AutoSize = true;
            lbSalary.ForeColor = Color.FromArgb(59, 93, 79);
            lbSalary.Location = new Point(435, 133);
            lbSalary.Name = "lbSalary";
            lbSalary.Size = new Size(51, 20);
            lbSalary.TabIndex = 14;
            lbSalary.Text = "Lương";
            // 
            // lbId
            // 
            lbId.AutoSize = true;
            lbId.ForeColor = Color.FromArgb(59, 93, 79);
            lbId.Location = new Point(15, 11);
            lbId.Name = "lbId";
            lbId.Size = new Size(97, 20);
            lbId.TabIndex = 0;
            lbId.Text = "Mã nhân viên";
            // 
            // lbAdress
            // 
            lbAdress.AutoSize = true;
            lbAdress.ForeColor = Color.FromArgb(59, 93, 79);
            lbAdress.Location = new Point(435, 11);
            lbAdress.Name = "lbAdress";
            lbAdress.Size = new Size(46, 20);
            lbAdress.TabIndex = 8;
            lbAdress.Text = "Nơi ở";
            // 
            // txtAddress
            // 
            txtAddress.BackColor = Color.White;
            txtAddress.BorderStyle = BorderStyle.None;
            txtAddress.ForeColor = Color.FromArgb(59, 93, 79);
            txtAddress.Location = new Point(515, 11);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(374, 20);
            txtAddress.TabIndex = 9;
            // 
            // lbBirthday
            // 
            lbBirthday.AutoSize = true;
            lbBirthday.ForeColor = Color.FromArgb(59, 93, 79);
            lbBirthday.Location = new Point(435, 45);
            lbBirthday.Name = "lbBirthday";
            lbBirthday.Size = new Size(74, 20);
            lbBirthday.TabIndex = 10;
            lbBirthday.Text = "Ngày sinh";
            // 
            // lbRole
            // 
            lbRole.AutoSize = true;
            lbRole.ForeColor = Color.FromArgb(59, 93, 79);
            lbRole.Location = new Point(435, 87);
            lbRole.Name = "lbRole";
            lbRole.Size = new Size(61, 20);
            lbRole.TabIndex = 12;
            lbRole.Text = "Chức vụ";
            // 
            // frmEmployee
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(1217, 807);
            Controls.Add(gbInfo);
            Controls.Add(dgv);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "frmEmployee";
            Text = "Danh sách nhân viên";
            Load += frmEmployee_Load;
            ((System.ComponentModel.ISupportInitialize)dgv).EndInit();
            gbInfo.ResumeLayout(false);
            flowLayoutPanel1.ResumeLayout(false);
            pnInfor.ResumeLayout(false);
            pnInfor.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2Button btnMod;
        private Guna.UI2.WinForms.Guna2Button btnDel;
        private Guna.UI2.WinForms.Guna2Button btnSearch;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2Button btnAdd;
        private Guna.UI2.WinForms.Guna2DataGridView dgv;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Guna.UI2.WinForms.Guna2GroupBox gbInfo;
        private Panel pnInfor;
        private FlowLayoutPanel flowLayoutPanel1;
        private Label lbName;
        private TextBox txtName;
        private TextBox txtIden;
        private TextBox txtId;
        private Guna.UI2.WinForms.Guna2ComboBox cbRole;
        private Label lbPhoneNumber;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpBirthDay;
        private Label lbCurrency;
        private TextBox txtPhoneNumber;
        private TextBox txtSalary;
        private Label lbIden;
        private Label lbSalary;
        private Label lbId;
        private Label lbAdress;
        private TextBox txtAddress;
        private Label lbBirthday;
        private Label lbRole;
        private Guna.UI2.WinForms.Guna2Button btnViewAttendance;
    }
}