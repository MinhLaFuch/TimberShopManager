﻿namespace timber_shop_manager
{
    partial class frmProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProduct));
            btnAdd = new Guna.UI2.WinForms.Guna2Button();
            btnDel = new Guna.UI2.WinForms.Guna2Button();
            btnMod = new Guna.UI2.WinForms.Guna2Button();
            btnSearch = new Guna.UI2.WinForms.Guna2Button();
            dgv = new Guna.UI2.WinForms.Guna2DataGridView();
            btnCancel = new Guna.UI2.WinForms.Guna2Button();
            btnSave = new Guna.UI2.WinForms.Guna2Button();
            gbInfo = new Guna.UI2.WinForms.Guna2GroupBox();
            pnInfo = new Panel();
            cbCalUnit = new ComboBox();
            txtDescription = new RichTextBox();
            lbDescription = new Label();
            cbCategory = new Guna.UI2.WinForms.Guna2ComboBox();
            txtId = new TextBox();
            txtName = new TextBox();
            lbVND = new Label();
            lbCategory = new Label();
            lbQuantity = new Label();
            nudQuantity = new Guna.UI2.WinForms.Guna2NumericUpDown();
            lbWarranty = new Label();
            lbId = new Label();
            lbMonth = new Label();
            nudWarranty = new Guna.UI2.WinForms.Guna2NumericUpDown();
            lbPriceQuotation = new Label();
            lbName = new Label();
            nudPriceQuotation = new Guna.UI2.WinForms.Guna2NumericUpDown();
            pnButton = new FlowLayoutPanel();
            flowLayoutPanel1 = new FlowLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)dgv).BeginInit();
            gbInfo.SuspendLayout();
            pnInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudQuantity).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudWarranty).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudPriceQuotation).BeginInit();
            pnButton.SuspendLayout();
            flowLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // btnAdd
            // 
            btnAdd.CustomizableEdges = customizableEdges1;
            btnAdd.DisabledState.BorderColor = Color.DarkGray;
            btnAdd.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAdd.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAdd.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAdd.FillColor = Color.FromArgb(59, 93, 79);
            btnAdd.Font = new Font("Segoe UI", 9F);
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(58, 3);
            btnAdd.Name = "btnAdd";
            btnAdd.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnAdd.Size = new Size(107, 40);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "Thêm";
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDel
            // 
            btnDel.CustomizableEdges = customizableEdges3;
            btnDel.DisabledState.BorderColor = Color.DarkGray;
            btnDel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDel.FillColor = Color.FromArgb(59, 93, 79);
            btnDel.Font = new Font("Segoe UI", 9F);
            btnDel.ForeColor = Color.White;
            btnDel.Location = new Point(284, 3);
            btnDel.Name = "btnDel";
            btnDel.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnDel.Size = new Size(107, 40);
            btnDel.TabIndex = 1;
            btnDel.Text = "Xóa";
            btnDel.Click += btnDel_Click;
            // 
            // btnMod
            // 
            btnMod.CustomizableEdges = customizableEdges5;
            btnMod.DisabledState.BorderColor = Color.DarkGray;
            btnMod.DisabledState.CustomBorderColor = Color.DarkGray;
            btnMod.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnMod.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnMod.FillColor = Color.FromArgb(59, 93, 79);
            btnMod.Font = new Font("Segoe UI", 9F);
            btnMod.ForeColor = Color.White;
            btnMod.Location = new Point(171, 3);
            btnMod.Name = "btnMod";
            btnMod.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnMod.Size = new Size(107, 40);
            btnMod.TabIndex = 2;
            btnMod.Text = "Sửa";
            btnMod.Click += btnMod_Click;
            // 
            // btnSearch
            // 
            btnSearch.CustomizableEdges = customizableEdges7;
            btnSearch.DisabledState.BorderColor = Color.DarkGray;
            btnSearch.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSearch.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSearch.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSearch.FillColor = Color.FromArgb(59, 93, 79);
            btnSearch.Font = new Font("Segoe UI", 9F);
            btnSearch.ForeColor = Color.White;
            btnSearch.Location = new Point(397, 3);
            btnSearch.Name = "btnSearch";
            btnSearch.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnSearch.Size = new Size(107, 40);
            btnSearch.TabIndex = 3;
            btnSearch.Text = "Tìm kiếm";
            btnSearch.Click += btnSearch_Click;
            // 
            // dgv
            // 
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.White;
            dgv.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgv.BackgroundColor = Color.Gainsboro;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgv.ColumnHeadersHeight = 50;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgv.DefaultCellStyle = dataGridViewCellStyle3;
            dgv.GridColor = Color.FromArgb(59, 93, 79);
            dgv.Location = new Point(3, 396);
            dgv.Name = "dgv";
            dgv.ReadOnly = true;
            dgv.RowHeadersVisible = false;
            dgv.RowHeadersWidth = 51;
            dgv.Size = new Size(1231, 467);
            dgv.TabIndex = 1;
            dgv.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgv.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgv.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgv.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgv.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgv.ThemeStyle.BackColor = Color.Gainsboro;
            dgv.ThemeStyle.GridColor = Color.FromArgb(59, 93, 79);
            dgv.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgv.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            dgv.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgv.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv.ThemeStyle.HeaderStyle.Height = 50;
            dgv.ThemeStyle.ReadOnly = true;
            dgv.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgv.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            dgv.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgv.ThemeStyle.RowsStyle.Height = 29;
            dgv.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgv.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgv.CellClick += dgvProduct_CellClick;
            // 
            // btnCancel
            // 
            btnCancel.CustomizableEdges = customizableEdges9;
            btnCancel.DisabledState.BorderColor = Color.DarkGray;
            btnCancel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCancel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCancel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCancel.FillColor = Color.FromArgb(59, 93, 79);
            btnCancel.Font = new Font("Segoe UI", 9F);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(623, 3);
            btnCancel.Name = "btnCancel";
            btnCancel.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnCancel.Size = new Size(107, 40);
            btnCancel.TabIndex = 1;
            btnCancel.Text = "Hủy";
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.CustomizableEdges = customizableEdges11;
            btnSave.DisabledState.BorderColor = Color.DarkGray;
            btnSave.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSave.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSave.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSave.FillColor = Color.FromArgb(59, 93, 79);
            btnSave.Font = new Font("Segoe UI", 9F);
            btnSave.ForeColor = Color.White;
            btnSave.Location = new Point(510, 3);
            btnSave.Name = "btnSave";
            btnSave.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnSave.Size = new Size(107, 40);
            btnSave.TabIndex = 0;
            btnSave.Text = "Lưu";
            btnSave.Click += btnSave_Click;
            // 
            // gbInfo
            // 
            gbInfo.Controls.Add(pnInfo);
            gbInfo.Controls.Add(pnButton);
            gbInfo.CustomBorderColor = Color.FromArgb(59, 93, 79);
            gbInfo.CustomizableEdges = customizableEdges21;
            gbInfo.FillColor = SystemColors.Control;
            gbInfo.Font = new Font("Segoe UI", 9F);
            gbInfo.ForeColor = Color.White;
            gbInfo.Location = new Point(3, 3);
            gbInfo.Name = "gbInfo";
            gbInfo.ShadowDecoration.CustomizableEdges = customizableEdges22;
            gbInfo.Size = new Size(1231, 387);
            gbInfo.TabIndex = 0;
            gbInfo.Text = "Thông tin";
            // 
            // pnInfo
            // 
            pnInfo.Controls.Add(cbCalUnit);
            pnInfo.Controls.Add(txtDescription);
            pnInfo.Controls.Add(lbDescription);
            pnInfo.Controls.Add(cbCategory);
            pnInfo.Controls.Add(txtId);
            pnInfo.Controls.Add(txtName);
            pnInfo.Controls.Add(lbVND);
            pnInfo.Controls.Add(lbCategory);
            pnInfo.Controls.Add(lbQuantity);
            pnInfo.Controls.Add(nudQuantity);
            pnInfo.Controls.Add(lbWarranty);
            pnInfo.Controls.Add(lbId);
            pnInfo.Controls.Add(lbMonth);
            pnInfo.Controls.Add(nudWarranty);
            pnInfo.Controls.Add(lbPriceQuotation);
            pnInfo.Controls.Add(lbName);
            pnInfo.Controls.Add(nudPriceQuotation);
            pnInfo.Location = new Point(3, 43);
            pnInfo.Name = "pnInfo";
            pnInfo.Size = new Size(1225, 261);
            pnInfo.TabIndex = 0;
            // 
            // cbCalUnit
            // 
            cbCalUnit.ForeColor = Color.FromArgb(59, 93, 79);
            cbCalUnit.FormattingEnabled = true;
            cbCalUnit.Location = new Point(305, 208);
            cbCalUnit.Name = "cbCalUnit";
            cbCalUnit.Size = new Size(186, 28);
            cbCalUnit.TabIndex = 14;
            // 
            // txtDescription
            // 
            txtDescription.BackColor = Color.White;
            txtDescription.BorderStyle = BorderStyle.None;
            txtDescription.Location = new Point(558, 30);
            txtDescription.Name = "txtDescription";
            txtDescription.ScrollBars = RichTextBoxScrollBars.ForcedHorizontal;
            txtDescription.Size = new Size(654, 217);
            txtDescription.TabIndex = 16;
            txtDescription.Text = "";
            // 
            // lbDescription
            // 
            lbDescription.AutoSize = true;
            lbDescription.ForeColor = Color.FromArgb(59, 93, 79);
            lbDescription.Location = new Point(558, 7);
            lbDescription.Name = "lbDescription";
            lbDescription.Size = new Size(48, 20);
            lbDescription.TabIndex = 15;
            lbDescription.Text = "Mô tả";
            // 
            // cbCategory
            // 
            cbCategory.BackColor = Color.Transparent;
            cbCategory.CustomizableEdges = customizableEdges13;
            cbCategory.DrawMode = DrawMode.OwnerDrawFixed;
            cbCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCategory.FocusedColor = Color.FromArgb(94, 148, 255);
            cbCategory.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbCategory.Font = new Font("Segoe UI", 10F);
            cbCategory.ForeColor = Color.FromArgb(59, 93, 79);
            cbCategory.ItemHeight = 30;
            cbCategory.Location = new Point(146, 111);
            cbCategory.Name = "cbCategory";
            cbCategory.ShadowDecoration.CustomizableEdges = customizableEdges14;
            cbCategory.Size = new Size(345, 36);
            cbCategory.TabIndex = 8;
            // 
            // txtId
            // 
            txtId.BackColor = Color.White;
            txtId.BorderStyle = BorderStyle.None;
            txtId.ForeColor = Color.FromArgb(59, 93, 79);
            txtId.Location = new Point(146, 7);
            txtId.Name = "txtId";
            txtId.Size = new Size(345, 20);
            txtId.TabIndex = 1;
            // 
            // txtName
            // 
            txtName.BackColor = Color.White;
            txtName.BorderStyle = BorderStyle.None;
            txtName.ForeColor = Color.FromArgb(59, 93, 79);
            txtName.Location = new Point(146, 44);
            txtName.Name = "txtName";
            txtName.Size = new Size(345, 20);
            txtName.TabIndex = 3;
            // 
            // lbVND
            // 
            lbVND.BackColor = Color.Transparent;
            lbVND.ForeColor = Color.FromArgb(59, 93, 79);
            lbVND.Location = new Point(305, 71);
            lbVND.Name = "lbVND";
            lbVND.Size = new Size(62, 31);
            lbVND.TabIndex = 6;
            lbVND.Text = "VND";
            lbVND.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbCategory
            // 
            lbCategory.AutoSize = true;
            lbCategory.ForeColor = Color.FromArgb(59, 93, 79);
            lbCategory.Location = new Point(19, 111);
            lbCategory.Name = "lbCategory";
            lbCategory.Size = new Size(37, 20);
            lbCategory.TabIndex = 7;
            lbCategory.Text = "Loại";
            // 
            // lbQuantity
            // 
            lbQuantity.AutoSize = true;
            lbQuantity.ForeColor = Color.FromArgb(59, 93, 79);
            lbQuantity.Location = new Point(19, 207);
            lbQuantity.Name = "lbQuantity";
            lbQuantity.Size = new Size(69, 20);
            lbQuantity.TabIndex = 12;
            lbQuantity.Text = "Số lượng";
            // 
            // nudQuantity
            // 
            nudQuantity.BackColor = Color.Transparent;
            nudQuantity.CustomizableEdges = customizableEdges15;
            nudQuantity.Font = new Font("Segoe UI", 9F);
            nudQuantity.ForeColor = Color.FromArgb(59, 93, 79);
            nudQuantity.Location = new Point(146, 203);
            nudQuantity.Margin = new Padding(3, 5, 3, 5);
            nudQuantity.Name = "nudQuantity";
            nudQuantity.ShadowDecoration.CustomizableEdges = customizableEdges16;
            nudQuantity.Size = new Size(142, 33);
            nudQuantity.TabIndex = 13;
            nudQuantity.UpDownButtonFillColor = Color.FromArgb(59, 93, 79);
            // 
            // lbWarranty
            // 
            lbWarranty.AutoSize = true;
            lbWarranty.ForeColor = Color.FromArgb(59, 93, 79);
            lbWarranty.Location = new Point(19, 167);
            lbWarranty.Name = "lbWarranty";
            lbWarranty.Size = new Size(102, 20);
            lbWarranty.TabIndex = 9;
            lbWarranty.Text = "Hạn bảo hành";
            // 
            // lbId
            // 
            lbId.AutoSize = true;
            lbId.ForeColor = Color.FromArgb(59, 93, 79);
            lbId.Location = new Point(19, 7);
            lbId.Name = "lbId";
            lbId.Size = new Size(98, 20);
            lbId.TabIndex = 0;
            lbId.Text = "Mã sản phẩm";
            // 
            // lbMonth
            // 
            lbMonth.BackColor = Color.Transparent;
            lbMonth.ForeColor = Color.FromArgb(59, 93, 79);
            lbMonth.Location = new Point(305, 163);
            lbMonth.Name = "lbMonth";
            lbMonth.Size = new Size(62, 31);
            lbMonth.TabIndex = 11;
            lbMonth.Text = "tháng";
            lbMonth.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // nudWarranty
            // 
            nudWarranty.BackColor = Color.Transparent;
            nudWarranty.CustomizableEdges = customizableEdges17;
            nudWarranty.Font = new Font("Segoe UI", 9F);
            nudWarranty.ForeColor = Color.FromArgb(59, 93, 79);
            nudWarranty.Location = new Point(146, 160);
            nudWarranty.Margin = new Padding(3, 5, 3, 5);
            nudWarranty.Name = "nudWarranty";
            nudWarranty.ShadowDecoration.CustomizableEdges = customizableEdges18;
            nudWarranty.Size = new Size(142, 33);
            nudWarranty.TabIndex = 10;
            nudWarranty.UpDownButtonFillColor = Color.FromArgb(59, 93, 79);
            // 
            // lbPriceQuotation
            // 
            lbPriceQuotation.AutoSize = true;
            lbPriceQuotation.ForeColor = Color.FromArgb(59, 93, 79);
            lbPriceQuotation.Location = new Point(19, 71);
            lbPriceQuotation.Name = "lbPriceQuotation";
            lbPriceQuotation.Size = new Size(62, 20);
            lbPriceQuotation.TabIndex = 4;
            lbPriceQuotation.Text = "Đơn giá";
            // 
            // lbName
            // 
            lbName.AutoSize = true;
            lbName.ForeColor = Color.FromArgb(59, 93, 79);
            lbName.Location = new Point(19, 44);
            lbName.Name = "lbName";
            lbName.Size = new Size(100, 20);
            lbName.TabIndex = 2;
            lbName.Text = "Tên sản phẩm";
            // 
            // nudPriceQuotation
            // 
            nudPriceQuotation.BackColor = Color.Transparent;
            nudPriceQuotation.CustomizableEdges = customizableEdges19;
            nudPriceQuotation.Font = new Font("Segoe UI", 9F);
            nudPriceQuotation.ForeColor = Color.FromArgb(59, 93, 79);
            nudPriceQuotation.Location = new Point(146, 71);
            nudPriceQuotation.Margin = new Padding(3, 5, 3, 5);
            nudPriceQuotation.Name = "nudPriceQuotation";
            nudPriceQuotation.ShadowDecoration.CustomizableEdges = customizableEdges20;
            nudPriceQuotation.Size = new Size(142, 33);
            nudPriceQuotation.TabIndex = 5;
            nudPriceQuotation.UpDownButtonFillColor = Color.FromArgb(59, 93, 79);
            // 
            // pnButton
            // 
            pnButton.Controls.Add(btnCancel);
            pnButton.Controls.Add(btnSave);
            pnButton.Controls.Add(btnSearch);
            pnButton.Controls.Add(btnDel);
            pnButton.Controls.Add(btnMod);
            pnButton.Controls.Add(btnAdd);
            pnButton.FlowDirection = FlowDirection.RightToLeft;
            pnButton.Location = new Point(485, 323);
            pnButton.Name = "pnButton";
            pnButton.Size = new Size(733, 48);
            pnButton.TabIndex = 1;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(gbInfo);
            flowLayoutPanel1.Controls.Add(dgv);
            flowLayoutPanel1.Location = new Point(-1, -4);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(1234, 863);
            flowLayoutPanel1.TabIndex = 2;
            // 
            // frmProduct
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1232, 865);
            Controls.Add(flowLayoutPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "frmProduct";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Sản phẩm";
            Load += frmProduct_Load;
            ((System.ComponentModel.ISupportInitialize)dgv).EndInit();
            gbInfo.ResumeLayout(false);
            pnInfo.ResumeLayout(false);
            pnInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudQuantity).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudWarranty).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudPriceQuotation).EndInit();
            pnButton.ResumeLayout(false);
            flowLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button btnAdd;
        private Guna.UI2.WinForms.Guna2Button btnDel;
        private Guna.UI2.WinForms.Guna2Button btnMod;
        private Guna.UI2.WinForms.Guna2Button btnSearch;
        private Guna.UI2.WinForms.Guna2DataGridView dgv;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2GroupBox gbInfo;
        private Panel pnInfo;
        private FlowLayoutPanel pnButton;
        private RichTextBox txtDescription;
        private Label lbDescription;
        private Guna.UI2.WinForms.Guna2ComboBox cbCategory;
        private TextBox txtId;
        private TextBox txtName;
        private Label lbVND;
        private Label lbCategory;
        private Label lbQuantity;
        private Guna.UI2.WinForms.Guna2NumericUpDown nudQuantity;
        private Label lbWarranty;
        private Label lbId;
        private Label lbMonth;
        private Guna.UI2.WinForms.Guna2NumericUpDown nudWarranty;
        private Label lbPriceQuotation;
        private Label lbName;
        private Guna.UI2.WinForms.Guna2NumericUpDown nudPriceQuotation;
        private ComboBox cbCalUnit;
        private FlowLayoutPanel flowLayoutPanel1;
    }
}