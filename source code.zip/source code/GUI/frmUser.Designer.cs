﻿namespace timber_shop_manager
{
    partial class frmUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUser));
            gbInfo = new Guna.UI2.WinForms.Guna2GroupBox();
            panel1 = new Panel();
            txtAdmission = new TextBox();
            txtName = new TextBox();
            txtEmail = new TextBox();
            txtIden = new TextBox();
            lbGmail = new Label();
            dtpBirthday = new Guna.UI2.WinForms.Guna2DateTimePicker();
            txtPhoneNumber = new TextBox();
            lbCurrency = new Label();
            txtSalary = new TextBox();
            lbSalary = new Label();
            lbEmployeeName = new Label();
            txtAddress = new TextBox();
            lbPhoneNumber = new Label();
            lbEmployeeRole = new Label();
            lbEmployeeIden = new Label();
            lbEmployeeDOB = new Label();
            lbEmployeeAddress = new Label();
            pnButton = new FlowLayoutPanel();
            btnCancel = new Guna.UI2.WinForms.Guna2Button();
            btnSave = new Guna.UI2.WinForms.Guna2Button();
            btnChangeInfo = new Guna.UI2.WinForms.Guna2Button();
            btnChangePW = new Guna.UI2.WinForms.Guna2Button();
            gbInfo.SuspendLayout();
            panel1.SuspendLayout();
            pnButton.SuspendLayout();
            SuspendLayout();
            // 
            // gbInfo
            // 
            gbInfo.Controls.Add(panel1);
            gbInfo.CustomBorderColor = Color.FromArgb(59, 93, 79);
            gbInfo.CustomizableEdges = customizableEdges3;
            gbInfo.FillColor = SystemColors.Control;
            gbInfo.Font = new Font("Segoe UI", 9F);
            gbInfo.ForeColor = Color.White;
            gbInfo.Location = new Point(11, 12);
            gbInfo.Name = "gbInfo";
            gbInfo.ShadowDecoration.CustomizableEdges = customizableEdges4;
            gbInfo.Size = new Size(1209, 252);
            gbInfo.TabIndex = 0;
            gbInfo.Text = "Thông tin cá nhân";
            // 
            // panel1
            // 
            panel1.Controls.Add(txtAdmission);
            panel1.Controls.Add(txtName);
            panel1.Controls.Add(txtEmail);
            panel1.Controls.Add(txtIden);
            panel1.Controls.Add(lbGmail);
            panel1.Controls.Add(dtpBirthday);
            panel1.Controls.Add(txtPhoneNumber);
            panel1.Controls.Add(lbCurrency);
            panel1.Controls.Add(txtSalary);
            panel1.Controls.Add(lbSalary);
            panel1.Controls.Add(lbEmployeeName);
            panel1.Controls.Add(txtAddress);
            panel1.Controls.Add(lbPhoneNumber);
            panel1.Controls.Add(lbEmployeeRole);
            panel1.Controls.Add(lbEmployeeIden);
            panel1.Controls.Add(lbEmployeeDOB);
            panel1.Controls.Add(lbEmployeeAddress);
            panel1.Location = new Point(3, 43);
            panel1.Name = "panel1";
            panel1.Size = new Size(1187, 197);
            panel1.TabIndex = 0;
            // 
            // txtAdmission
            // 
            txtAdmission.BackColor = Color.White;
            txtAdmission.BorderStyle = BorderStyle.None;
            txtAdmission.ForeColor = Color.FromArgb(59, 93, 79);
            txtAdmission.Location = new Point(641, 109);
            txtAdmission.Name = "txtAdmission";
            txtAdmission.ReadOnly = true;
            txtAdmission.Size = new Size(198, 20);
            txtAdmission.TabIndex = 13;
            // 
            // txtName
            // 
            txtName.BackColor = Color.White;
            txtName.BorderStyle = BorderStyle.None;
            txtName.ForeColor = Color.FromArgb(59, 93, 79);
            txtName.Location = new Point(168, 63);
            txtName.Name = "txtName";
            txtName.Size = new Size(345, 20);
            txtName.TabIndex = 3;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = Color.White;
            txtEmail.BorderStyle = BorderStyle.None;
            txtEmail.ForeColor = Color.FromArgb(59, 93, 79);
            txtEmail.Location = new Point(168, 20);
            txtEmail.Name = "txtEmail";
            txtEmail.ReadOnly = true;
            txtEmail.Size = new Size(345, 20);
            txtEmail.TabIndex = 1;
            // 
            // txtIden
            // 
            txtIden.BackColor = Color.White;
            txtIden.BorderStyle = BorderStyle.None;
            txtIden.ForeColor = Color.FromArgb(59, 93, 79);
            txtIden.Location = new Point(168, 108);
            txtIden.Name = "txtIden";
            txtIden.Size = new Size(345, 20);
            txtIden.TabIndex = 5;
            // 
            // lbGmail
            // 
            lbGmail.AutoSize = true;
            lbGmail.ForeColor = Color.FromArgb(59, 93, 79);
            lbGmail.Location = new Point(26, 20);
            lbGmail.Name = "lbGmail";
            lbGmail.Size = new Size(48, 20);
            lbGmail.TabIndex = 0;
            lbGmail.Text = "Gmail";
            // 
            // dtpBirthday
            // 
            dtpBirthday.BackColor = SystemColors.ControlDark;
            dtpBirthday.Checked = true;
            dtpBirthday.CustomFormat = "dd/MM/yyyy";
            dtpBirthday.CustomizableEdges = customizableEdges1;
            dtpBirthday.FillColor = Color.FromArgb(59, 93, 79);
            dtpBirthday.Font = new Font("Segoe UI", 9F);
            dtpBirthday.Format = DateTimePickerFormat.Custom;
            dtpBirthday.Location = new Point(641, 53);
            dtpBirthday.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpBirthday.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpBirthday.Name = "dtpBirthday";
            dtpBirthday.ShadowDecoration.CustomizableEdges = customizableEdges2;
            dtpBirthday.Size = new Size(149, 32);
            dtpBirthday.TabIndex = 11;
            dtpBirthday.Value = new DateTime(2025, 4, 14, 10, 47, 29, 149);
            // 
            // txtPhoneNumber
            // 
            txtPhoneNumber.BackColor = Color.White;
            txtPhoneNumber.BorderStyle = BorderStyle.None;
            txtPhoneNumber.ForeColor = Color.FromArgb(59, 93, 79);
            txtPhoneNumber.Location = new Point(168, 145);
            txtPhoneNumber.Name = "txtPhoneNumber";
            txtPhoneNumber.Size = new Size(345, 20);
            txtPhoneNumber.TabIndex = 7;
            // 
            // lbCurrency
            // 
            lbCurrency.AutoSize = true;
            lbCurrency.ForeColor = Color.FromArgb(59, 93, 79);
            lbCurrency.Location = new Point(865, 151);
            lbCurrency.Name = "lbCurrency";
            lbCurrency.Size = new Size(122, 20);
            lbCurrency.TabIndex = 16;
            lbCurrency.Text = "VND/ Ngày công";
            // 
            // txtSalary
            // 
            txtSalary.BackColor = Color.White;
            txtSalary.BorderStyle = BorderStyle.None;
            txtSalary.Location = new Point(641, 151);
            txtSalary.Name = "txtSalary";
            txtSalary.ReadOnly = true;
            txtSalary.Size = new Size(198, 20);
            txtSalary.TabIndex = 15;
            // 
            // lbSalary
            // 
            lbSalary.AutoSize = true;
            lbSalary.ForeColor = Color.FromArgb(59, 93, 79);
            lbSalary.Location = new Point(544, 151);
            lbSalary.Name = "lbSalary";
            lbSalary.Size = new Size(51, 20);
            lbSalary.TabIndex = 14;
            lbSalary.Text = "Lương";
            // 
            // lbEmployeeName
            // 
            lbEmployeeName.AutoSize = true;
            lbEmployeeName.ForeColor = Color.FromArgb(59, 93, 79);
            lbEmployeeName.Location = new Point(27, 63);
            lbEmployeeName.Name = "lbEmployeeName";
            lbEmployeeName.Size = new Size(54, 20);
            lbEmployeeName.TabIndex = 2;
            lbEmployeeName.Text = "Họ tên";
            // 
            // txtAddress
            // 
            txtAddress.BackColor = Color.White;
            txtAddress.BorderStyle = BorderStyle.None;
            txtAddress.ForeColor = Color.FromArgb(59, 93, 79);
            txtAddress.Location = new Point(641, 20);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(519, 20);
            txtAddress.TabIndex = 9;
            // 
            // lbPhoneNumber
            // 
            lbPhoneNumber.AutoSize = true;
            lbPhoneNumber.ForeColor = Color.FromArgb(59, 93, 79);
            lbPhoneNumber.Location = new Point(27, 145);
            lbPhoneNumber.Name = "lbPhoneNumber";
            lbPhoneNumber.Size = new Size(97, 20);
            lbPhoneNumber.TabIndex = 6;
            lbPhoneNumber.Text = "Số điện thoại";
            // 
            // lbEmployeeRole
            // 
            lbEmployeeRole.AutoSize = true;
            lbEmployeeRole.ForeColor = Color.FromArgb(59, 93, 79);
            lbEmployeeRole.Location = new Point(544, 109);
            lbEmployeeRole.Name = "lbEmployeeRole";
            lbEmployeeRole.Size = new Size(61, 20);
            lbEmployeeRole.TabIndex = 12;
            lbEmployeeRole.Text = "Chức vụ";
            // 
            // lbEmployeeIden
            // 
            lbEmployeeIden.AutoSize = true;
            lbEmployeeIden.ForeColor = Color.FromArgb(59, 93, 79);
            lbEmployeeIden.Location = new Point(27, 108);
            lbEmployeeIden.Name = "lbEmployeeIden";
            lbEmployeeIden.Size = new Size(68, 20);
            lbEmployeeIden.TabIndex = 4;
            lbEmployeeIden.Text = "Số CCCD";
            // 
            // lbEmployeeDOB
            // 
            lbEmployeeDOB.AutoSize = true;
            lbEmployeeDOB.ForeColor = Color.FromArgb(59, 93, 79);
            lbEmployeeDOB.Location = new Point(544, 61);
            lbEmployeeDOB.Name = "lbEmployeeDOB";
            lbEmployeeDOB.Size = new Size(74, 20);
            lbEmployeeDOB.TabIndex = 10;
            lbEmployeeDOB.Text = "Ngày sinh";
            // 
            // lbEmployeeAddress
            // 
            lbEmployeeAddress.AutoSize = true;
            lbEmployeeAddress.ForeColor = Color.FromArgb(59, 93, 79);
            lbEmployeeAddress.Location = new Point(544, 20);
            lbEmployeeAddress.Name = "lbEmployeeAddress";
            lbEmployeeAddress.Size = new Size(46, 20);
            lbEmployeeAddress.TabIndex = 8;
            lbEmployeeAddress.Text = "Nơi ở";
            // 
            // pnButton
            // 
            pnButton.Controls.Add(btnCancel);
            pnButton.Controls.Add(btnSave);
            pnButton.Controls.Add(btnChangeInfo);
            pnButton.Controls.Add(btnChangePW);
            pnButton.FlowDirection = FlowDirection.RightToLeft;
            pnButton.Location = new Point(459, 283);
            pnButton.Name = "pnButton";
            pnButton.Size = new Size(742, 70);
            pnButton.TabIndex = 1;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.FromArgb(59, 93, 79);
            btnCancel.CustomizableEdges = customizableEdges5;
            btnCancel.DisabledState.BorderColor = Color.DarkGray;
            btnCancel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCancel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCancel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCancel.FillColor = Color.FromArgb(59, 93, 79);
            btnCancel.Font = new Font("Segoe UI", 9F);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(576, 3);
            btnCancel.Name = "btnCancel";
            btnCancel.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnCancel.Size = new Size(163, 50);
            btnCancel.TabIndex = 0;
            btnCancel.Text = "Hủy";
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.BackColor = Color.FromArgb(59, 93, 79);
            btnSave.CustomizableEdges = customizableEdges7;
            btnSave.DisabledState.BorderColor = Color.DarkGray;
            btnSave.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSave.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSave.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSave.FillColor = Color.FromArgb(59, 93, 79);
            btnSave.Font = new Font("Segoe UI", 9F);
            btnSave.ForeColor = Color.White;
            btnSave.Location = new Point(407, 3);
            btnSave.Name = "btnSave";
            btnSave.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnSave.Size = new Size(163, 50);
            btnSave.TabIndex = 1;
            btnSave.Text = "Lưu";
            btnSave.Click += btnSave_Click;
            // 
            // btnChangeInfo
            // 
            btnChangeInfo.BackColor = Color.FromArgb(59, 93, 79);
            btnChangeInfo.CustomizableEdges = customizableEdges9;
            btnChangeInfo.DisabledState.BorderColor = Color.DarkGray;
            btnChangeInfo.DisabledState.CustomBorderColor = Color.DarkGray;
            btnChangeInfo.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnChangeInfo.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnChangeInfo.FillColor = Color.FromArgb(59, 93, 79);
            btnChangeInfo.Font = new Font("Segoe UI", 9F);
            btnChangeInfo.ForeColor = Color.White;
            btnChangeInfo.Location = new Point(238, 3);
            btnChangeInfo.Name = "btnChangeInfo";
            btnChangeInfo.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnChangeInfo.Size = new Size(163, 50);
            btnChangeInfo.TabIndex = 1;
            btnChangeInfo.Text = "Sửa thông tin";
            btnChangeInfo.Click += btnChangeInfo_Click;
            // 
            // btnChangePW
            // 
            btnChangePW.BackColor = Color.FromArgb(59, 93, 79);
            btnChangePW.CustomizableEdges = customizableEdges11;
            btnChangePW.DisabledState.BorderColor = Color.DarkGray;
            btnChangePW.DisabledState.CustomBorderColor = Color.DarkGray;
            btnChangePW.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnChangePW.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnChangePW.FillColor = Color.FromArgb(59, 93, 79);
            btnChangePW.Font = new Font("Segoe UI", 9F);
            btnChangePW.ForeColor = Color.White;
            btnChangePW.Location = new Point(69, 3);
            btnChangePW.Name = "btnChangePW";
            btnChangePW.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnChangePW.Size = new Size(163, 50);
            btnChangePW.TabIndex = 0;
            btnChangePW.Text = "Đổi mật khẩu";
            btnChangePW.Click += btnChangePW_Click;
            // 
            // frmUser
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1232, 865);
            Controls.Add(gbInfo);
            Controls.Add(pnButton);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "frmUser";
            Text = "frmUser";
            Load += frmUser_Load;
            gbInfo.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            pnButton.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2GroupBox gbInfo;
        private Guna.UI2.WinForms.Guna2Button btnChangeInfo;
        private Guna.UI2.WinForms.Guna2Button btnChangePW;
        private FlowLayoutPanel pnButton;
        private Panel panel1;
        private TextBox txtName;
        private TextBox txtEmail;
        private TextBox txtIden;
        private Label lbGmail;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpBirthday;
        private TextBox txtPhoneNumber;
        private Label lbCurrency;
        private TextBox txtSalary;
        private Label lbSalary;
        private Label lbEmployeeName;
        private TextBox txtAddress;
        private Label lbPhoneNumber;
        private Label lbEmployeeRole;
        private Label lbEmployeeIden;
        private Label lbEmployeeDOB;
        private Label lbEmployeeAddress;
        private TextBox txtAdmission;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2Button btnSave;
    }
}