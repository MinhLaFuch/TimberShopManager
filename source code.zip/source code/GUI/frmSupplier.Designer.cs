﻿namespace timber_shop_manager.GUI
{
    partial class frmSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSupplier));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            btnViewDetail = new Guna.UI2.WinForms.Guna2Button();
            lbInvoiceId = new Label();
            txtInvoiceId = new TextBox();
            dtpTimeTo = new Guna.UI2.WinForms.Guna2DateTimePicker();
            dtpTimeFrom = new Guna.UI2.WinForms.Guna2DateTimePicker();
            pbArrow = new PictureBox();
            panel1 = new Panel();
            pnPurchase = new Panel();
            gbPurchaseHistory = new Guna.UI2.WinForms.Guna2GroupBox();
            btnSave = new Guna.UI2.WinForms.Guna2Button();
            btnCancel = new Guna.UI2.WinForms.Guna2Button();
            btnSearch = new Guna.UI2.WinForms.Guna2Button();
            btnMod = new Guna.UI2.WinForms.Guna2Button();
            btnAdd = new Guna.UI2.WinForms.Guna2Button();
            btnDelete = new Guna.UI2.WinForms.Guna2Button();
            pnButton = new FlowLayoutPanel();
            pnInfo = new Panel();
            txtWebsite = new TextBox();
            lbWebsite = new Label();
            txtEmail = new TextBox();
            label2 = new Label();
            txtPhoneNumber = new TextBox();
            label1 = new Label();
            txtName = new TextBox();
            txtAddress = new TextBox();
            lbAddress = new Label();
            lbName = new Label();
            txtId = new TextBox();
            lbId = new Label();
            gbInfo = new Guna.UI2.WinForms.Guna2GroupBox();
            dgvSupplier = new Guna.UI2.WinForms.Guna2DataGridView();
            dgvPurchase = new Guna.UI2.WinForms.Guna2DataGridView();
            ((System.ComponentModel.ISupportInitialize)pbArrow).BeginInit();
            panel1.SuspendLayout();
            pnPurchase.SuspendLayout();
            gbPurchaseHistory.SuspendLayout();
            pnButton.SuspendLayout();
            pnInfo.SuspendLayout();
            gbInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvSupplier).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvPurchase).BeginInit();
            SuspendLayout();
            // 
            // btnViewDetail
            // 
            btnViewDetail.CustomizableEdges = customizableEdges1;
            btnViewDetail.DisabledState.BorderColor = Color.DarkGray;
            btnViewDetail.DisabledState.CustomBorderColor = Color.DarkGray;
            btnViewDetail.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnViewDetail.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnViewDetail.FillColor = Color.FromArgb(59, 93, 79);
            btnViewDetail.Font = new Font("Segoe UI", 9F);
            btnViewDetail.ForeColor = Color.White;
            btnViewDetail.Location = new Point(1054, 264);
            btnViewDetail.Name = "btnViewDetail";
            btnViewDetail.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnViewDetail.Size = new Size(138, 37);
            btnViewDetail.TabIndex = 3;
            btnViewDetail.Text = "Xem chi tiết";
            btnViewDetail.Click += btnViewDetail_Click;
            // 
            // lbInvoiceId
            // 
            lbInvoiceId.AutoSize = true;
            lbInvoiceId.ForeColor = Color.FromArgb(59, 93, 79);
            lbInvoiceId.Location = new Point(16, 104);
            lbInvoiceId.Name = "lbInvoiceId";
            lbInvoiceId.Size = new Size(89, 20);
            lbInvoiceId.TabIndex = 1;
            lbInvoiceId.Text = "Mã hoá đơn";
            // 
            // txtInvoiceId
            // 
            txtInvoiceId.BackColor = Color.White;
            txtInvoiceId.BorderStyle = BorderStyle.None;
            txtInvoiceId.Enabled = false;
            txtInvoiceId.ForeColor = Color.FromArgb(59, 93, 79);
            txtInvoiceId.Location = new Point(177, 104);
            txtInvoiceId.Margin = new Padding(3, 4, 3, 4);
            txtInvoiceId.Name = "txtInvoiceId";
            txtInvoiceId.Size = new Size(237, 20);
            txtInvoiceId.TabIndex = 2;
            txtInvoiceId.TextChanged += txtInvoiceId_TextChanged;
            // 
            // dtpTimeTo
            // 
            dtpTimeTo.Checked = true;
            dtpTimeTo.CustomFormat = "dd/MM/yyyy";
            dtpTimeTo.CustomizableEdges = customizableEdges3;
            dtpTimeTo.FillColor = Color.FromArgb(59, 93, 79);
            dtpTimeTo.Font = new Font("Segoe UI", 9F);
            dtpTimeTo.Format = DateTimePickerFormat.Custom;
            dtpTimeTo.Location = new Point(240, 12);
            dtpTimeTo.Margin = new Padding(3, 4, 3, 4);
            dtpTimeTo.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpTimeTo.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpTimeTo.Name = "dtpTimeTo";
            dtpTimeTo.ShadowDecoration.CustomizableEdges = customizableEdges4;
            dtpTimeTo.Size = new Size(166, 48);
            dtpTimeTo.TabIndex = 1;
            dtpTimeTo.Value = new DateTime(2025, 4, 29, 22, 40, 11, 296);
            dtpTimeTo.ValueChanged += dtp_ValueChanged;
            // 
            // dtpTimeFrom
            // 
            dtpTimeFrom.Checked = true;
            dtpTimeFrom.CustomFormat = "dd/MM/yyyy";
            dtpTimeFrom.CustomizableEdges = customizableEdges5;
            dtpTimeFrom.FillColor = Color.FromArgb(59, 93, 79);
            dtpTimeFrom.Font = new Font("Segoe UI", 9F);
            dtpTimeFrom.Format = DateTimePickerFormat.Custom;
            dtpTimeFrom.Location = new Point(8, 12);
            dtpTimeFrom.Margin = new Padding(3, 4, 3, 4);
            dtpTimeFrom.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpTimeFrom.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpTimeFrom.Name = "dtpTimeFrom";
            dtpTimeFrom.ShadowDecoration.CustomizableEdges = customizableEdges6;
            dtpTimeFrom.Size = new Size(166, 48);
            dtpTimeFrom.TabIndex = 0;
            dtpTimeFrom.Value = new DateTime(2025, 4, 29, 22, 40, 11, 296);
            dtpTimeFrom.ValueChanged += dtp_ValueChanged;
            // 
            // pbArrow
            // 
            pbArrow.Image = (Image)resources.GetObject("pbArrow.Image");
            pbArrow.Location = new Point(169, 13);
            pbArrow.Name = "pbArrow";
            pbArrow.Size = new Size(81, 47);
            pbArrow.SizeMode = PictureBoxSizeMode.CenterImage;
            pbArrow.TabIndex = 26;
            pbArrow.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(dtpTimeTo);
            panel1.Controls.Add(dtpTimeFrom);
            panel1.Controls.Add(pbArrow);
            panel1.Location = new Point(8, 11);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(431, 72);
            panel1.TabIndex = 0;
            // 
            // pnPurchase
            // 
            pnPurchase.Controls.Add(panel1);
            pnPurchase.Controls.Add(lbInvoiceId);
            pnPurchase.Controls.Add(txtInvoiceId);
            pnPurchase.Location = new Point(16, 51);
            pnPurchase.Name = "pnPurchase";
            pnPurchase.Size = new Size(448, 183);
            pnPurchase.TabIndex = 0;
            // 
            // gbPurchaseHistory
            // 
            gbPurchaseHistory.Controls.Add(pnPurchase);
            gbPurchaseHistory.CustomBorderColor = Color.FromArgb(59, 93, 79);
            gbPurchaseHistory.CustomizableEdges = customizableEdges7;
            gbPurchaseHistory.Enabled = false;
            gbPurchaseHistory.FillColor = SystemColors.Control;
            gbPurchaseHistory.Font = new Font("Segoe UI", 9F);
            gbPurchaseHistory.ForeColor = Color.White;
            gbPurchaseHistory.Location = new Point(728, 4);
            gbPurchaseHistory.Name = "gbPurchaseHistory";
            gbPurchaseHistory.ShadowDecoration.CustomizableEdges = customizableEdges8;
            gbPurchaseHistory.Size = new Size(475, 241);
            gbPurchaseHistory.TabIndex = 1;
            gbPurchaseHistory.Text = "Lịch sử thanh toán";
            gbPurchaseHistory.EnabledChanged += gbPurchaseHistory_EnabledChanged;
            // 
            // btnSave
            // 
            btnSave.CustomizableEdges = customizableEdges9;
            btnSave.DisabledState.BorderColor = Color.DarkGray;
            btnSave.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSave.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSave.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSave.FillColor = Color.FromArgb(59, 93, 79);
            btnSave.Font = new Font("Segoe UI", 9F);
            btnSave.ForeColor = Color.White;
            btnSave.Location = new Point(432, 3);
            btnSave.Name = "btnSave";
            btnSave.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnSave.Size = new Size(138, 47);
            btnSave.TabIndex = 1;
            btnSave.Text = "Lưu";
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.CustomizableEdges = customizableEdges11;
            btnCancel.DisabledState.BorderColor = Color.DarkGray;
            btnCancel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCancel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCancel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCancel.FillColor = Color.FromArgb(59, 93, 79);
            btnCancel.Font = new Font("Segoe UI", 9F);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(576, 3);
            btnCancel.Name = "btnCancel";
            btnCancel.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnCancel.Size = new Size(138, 47);
            btnCancel.TabIndex = 0;
            btnCancel.Text = "Hủy";
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSearch
            // 
            btnSearch.CustomizableEdges = customizableEdges13;
            btnSearch.DisabledState.BorderColor = Color.DarkGray;
            btnSearch.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSearch.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSearch.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSearch.FillColor = Color.FromArgb(59, 93, 79);
            btnSearch.Font = new Font("Segoe UI", 9F);
            btnSearch.ForeColor = Color.White;
            btnSearch.Location = new Point(288, 3);
            btnSearch.Name = "btnSearch";
            btnSearch.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btnSearch.Size = new Size(138, 47);
            btnSearch.TabIndex = 3;
            btnSearch.Text = "Tìm kiếm";
            btnSearch.Click += btnSearch_Click;
            // 
            // btnMod
            // 
            btnMod.CustomizableEdges = customizableEdges15;
            btnMod.DisabledState.BorderColor = Color.DarkGray;
            btnMod.DisabledState.CustomBorderColor = Color.DarkGray;
            btnMod.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnMod.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnMod.FillColor = Color.FromArgb(59, 93, 79);
            btnMod.Font = new Font("Segoe UI", 9F);
            btnMod.ForeColor = Color.White;
            btnMod.Location = new Point(576, 56);
            btnMod.Name = "btnMod";
            btnMod.ShadowDecoration.CustomizableEdges = customizableEdges16;
            btnMod.Size = new Size(138, 47);
            btnMod.TabIndex = 2;
            btnMod.Text = "Sửa";
            btnMod.Click += btnMod_Click;
            // 
            // btnAdd
            // 
            btnAdd.CustomizableEdges = customizableEdges17;
            btnAdd.DisabledState.BorderColor = Color.DarkGray;
            btnAdd.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAdd.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAdd.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAdd.FillColor = Color.FromArgb(59, 93, 79);
            btnAdd.Font = new Font("Segoe UI", 9F);
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(432, 56);
            btnAdd.Name = "btnAdd";
            btnAdd.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnAdd.Size = new Size(138, 47);
            btnAdd.TabIndex = 1;
            btnAdd.Text = "Thêm";
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDelete
            // 
            btnDelete.CustomizableEdges = customizableEdges19;
            btnDelete.DisabledState.BorderColor = Color.DarkGray;
            btnDelete.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDelete.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDelete.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDelete.FillColor = Color.FromArgb(59, 93, 79);
            btnDelete.Font = new Font("Segoe UI", 9F);
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(144, 3);
            btnDelete.Name = "btnDelete";
            btnDelete.ShadowDecoration.CustomizableEdges = customizableEdges20;
            btnDelete.Size = new Size(138, 47);
            btnDelete.TabIndex = 0;
            btnDelete.Text = "Xoá";
            btnDelete.Click += btnDelete_Click;
            // 
            // pnButton
            // 
            pnButton.Controls.Add(btnCancel);
            pnButton.Controls.Add(btnSave);
            pnButton.Controls.Add(btnSearch);
            pnButton.Controls.Add(btnDelete);
            pnButton.Controls.Add(btnMod);
            pnButton.Controls.Add(btnAdd);
            pnButton.FlowDirection = FlowDirection.RightToLeft;
            pnButton.Location = new Point(10, 251);
            pnButton.Name = "pnButton";
            pnButton.Size = new Size(717, 65);
            pnButton.TabIndex = 2;
            // 
            // pnInfo
            // 
            pnInfo.Controls.Add(txtWebsite);
            pnInfo.Controls.Add(lbWebsite);
            pnInfo.Controls.Add(txtEmail);
            pnInfo.Controls.Add(label2);
            pnInfo.Controls.Add(txtPhoneNumber);
            pnInfo.Controls.Add(label1);
            pnInfo.Controls.Add(txtName);
            pnInfo.Controls.Add(txtAddress);
            pnInfo.Controls.Add(lbAddress);
            pnInfo.Controls.Add(lbName);
            pnInfo.Controls.Add(txtId);
            pnInfo.Controls.Add(lbId);
            pnInfo.Location = new Point(11, 51);
            pnInfo.Name = "pnInfo";
            pnInfo.Size = new Size(634, 183);
            pnInfo.TabIndex = 0;
            // 
            // txtWebsite
            // 
            txtWebsite.BackColor = Color.White;
            txtWebsite.BorderStyle = BorderStyle.None;
            txtWebsite.ForeColor = Color.FromArgb(59, 93, 79);
            txtWebsite.Location = new Point(176, 148);
            txtWebsite.Margin = new Padding(3, 4, 3, 4);
            txtWebsite.Name = "txtWebsite";
            txtWebsite.Size = new Size(373, 20);
            txtWebsite.TabIndex = 11;
            // 
            // lbWebsite
            // 
            lbWebsite.AutoSize = true;
            lbWebsite.ForeColor = Color.FromArgb(59, 93, 79);
            lbWebsite.Location = new Point(15, 148);
            lbWebsite.Name = "lbWebsite";
            lbWebsite.Size = new Size(62, 20);
            lbWebsite.TabIndex = 10;
            lbWebsite.Text = "Website";
            // 
            // txtEmail
            // 
            txtEmail.BackColor = Color.White;
            txtEmail.BorderStyle = BorderStyle.None;
            txtEmail.ForeColor = Color.FromArgb(59, 93, 79);
            txtEmail.Location = new Point(176, 121);
            txtEmail.Margin = new Padding(3, 4, 3, 4);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(373, 20);
            txtEmail.TabIndex = 9;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.FromArgb(59, 93, 79);
            label2.Location = new Point(15, 121);
            label2.Name = "label2";
            label2.Size = new Size(46, 20);
            label2.TabIndex = 8;
            label2.Text = "Email";
            // 
            // txtPhoneNumber
            // 
            txtPhoneNumber.BackColor = Color.White;
            txtPhoneNumber.BorderStyle = BorderStyle.None;
            txtPhoneNumber.ForeColor = Color.FromArgb(59, 93, 79);
            txtPhoneNumber.Location = new Point(176, 92);
            txtPhoneNumber.Margin = new Padding(3, 4, 3, 4);
            txtPhoneNumber.Name = "txtPhoneNumber";
            txtPhoneNumber.Size = new Size(373, 20);
            txtPhoneNumber.TabIndex = 7;
            txtPhoneNumber.KeyPress += txtPhoneNumber_KeyPress;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.FromArgb(59, 93, 79);
            label1.Location = new Point(15, 92);
            label1.Name = "label1";
            label1.Size = new Size(97, 20);
            label1.TabIndex = 6;
            label1.Text = "Số điện thoại";
            // 
            // txtName
            // 
            txtName.BackColor = Color.White;
            txtName.BorderStyle = BorderStyle.None;
            txtName.ForeColor = Color.FromArgb(59, 93, 79);
            txtName.Location = new Point(176, 33);
            txtName.Margin = new Padding(3, 4, 3, 4);
            txtName.Name = "txtName";
            txtName.Size = new Size(373, 20);
            txtName.TabIndex = 3;
            // 
            // txtAddress
            // 
            txtAddress.BackColor = Color.White;
            txtAddress.BorderStyle = BorderStyle.None;
            txtAddress.ForeColor = Color.FromArgb(59, 93, 79);
            txtAddress.Location = new Point(176, 63);
            txtAddress.Margin = new Padding(3, 4, 3, 4);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(373, 20);
            txtAddress.TabIndex = 5;
            // 
            // lbAddress
            // 
            lbAddress.AutoSize = true;
            lbAddress.ForeColor = Color.FromArgb(59, 93, 79);
            lbAddress.Location = new Point(15, 63);
            lbAddress.Name = "lbAddress";
            lbAddress.Size = new Size(55, 20);
            lbAddress.TabIndex = 4;
            lbAddress.Text = "Địa chỉ";
            // 
            // lbName
            // 
            lbName.AutoSize = true;
            lbName.ForeColor = Color.FromArgb(59, 93, 79);
            lbName.Location = new Point(15, 33);
            lbName.Name = "lbName";
            lbName.Size = new Size(32, 20);
            lbName.TabIndex = 2;
            lbName.Text = "Tên";
            // 
            // txtId
            // 
            txtId.BackColor = Color.White;
            txtId.BorderStyle = BorderStyle.None;
            txtId.ForeColor = Color.FromArgb(59, 93, 79);
            txtId.Location = new Point(176, 5);
            txtId.Margin = new Padding(3, 4, 3, 4);
            txtId.Name = "txtId";
            txtId.Size = new Size(373, 20);
            txtId.TabIndex = 1;
            // 
            // lbId
            // 
            lbId.AutoSize = true;
            lbId.ForeColor = Color.FromArgb(59, 93, 79);
            lbId.Location = new Point(15, 5);
            lbId.Name = "lbId";
            lbId.Size = new Size(30, 20);
            lbId.TabIndex = 0;
            lbId.Text = "Mã";
            // 
            // gbInfo
            // 
            gbInfo.Controls.Add(pnInfo);
            gbInfo.CustomBorderColor = Color.FromArgb(59, 93, 79);
            gbInfo.CustomizableEdges = customizableEdges21;
            gbInfo.FillColor = SystemColors.Control;
            gbInfo.Font = new Font("Segoe UI", 9F);
            gbInfo.ForeColor = Color.White;
            gbInfo.Location = new Point(10, 4);
            gbInfo.Name = "gbInfo";
            gbInfo.ShadowDecoration.CustomizableEdges = customizableEdges22;
            gbInfo.Size = new Size(711, 241);
            gbInfo.TabIndex = 0;
            gbInfo.Text = "Thông tin";
            // 
            // dgvSupplier
            // 
            dgvSupplier.AllowUserToAddRows = false;
            dgvSupplier.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.White;
            dgvSupplier.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgvSupplier.BackgroundColor = Color.Gainsboro;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgvSupplier.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgvSupplier.ColumnHeadersHeight = 50;
            dgvSupplier.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgvSupplier.DefaultCellStyle = dataGridViewCellStyle3;
            dgvSupplier.GridColor = Color.FromArgb(231, 229, 255);
            dgvSupplier.Location = new Point(10, 321);
            dgvSupplier.Name = "dgvSupplier";
            dgvSupplier.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = Color.White;
            dataGridViewCellStyle4.SelectionBackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dgvSupplier.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dgvSupplier.RowHeadersVisible = false;
            dgvSupplier.RowHeadersWidth = 51;
            dgvSupplier.Size = new Size(709, 495);
            dgvSupplier.TabIndex = 4;
            dgvSupplier.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgvSupplier.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgvSupplier.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgvSupplier.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgvSupplier.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgvSupplier.ThemeStyle.BackColor = Color.Gainsboro;
            dgvSupplier.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgvSupplier.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgvSupplier.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvSupplier.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            dgvSupplier.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgvSupplier.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgvSupplier.ThemeStyle.HeaderStyle.Height = 50;
            dgvSupplier.ThemeStyle.ReadOnly = true;
            dgvSupplier.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgvSupplier.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvSupplier.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            dgvSupplier.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgvSupplier.ThemeStyle.RowsStyle.Height = 29;
            dgvSupplier.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgvSupplier.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgvSupplier.CellClick += dgvSupplier_CellClick;
            // 
            // dgvPurchase
            // 
            dgvPurchase.AllowUserToAddRows = false;
            dgvPurchase.AllowUserToDeleteRows = false;
            dataGridViewCellStyle5.BackColor = Color.White;
            dgvPurchase.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            dgvPurchase.BackgroundColor = Color.LightGray;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle6.ForeColor = Color.White;
            dataGridViewCellStyle6.SelectionBackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            dgvPurchase.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dgvPurchase.ColumnHeadersHeight = 50;
            dgvPurchase.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = Color.White;
            dataGridViewCellStyle7.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle7.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle7.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle7.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.False;
            dgvPurchase.DefaultCellStyle = dataGridViewCellStyle7;
            dgvPurchase.GridColor = Color.FromArgb(231, 229, 255);
            dgvPurchase.Location = new Point(728, 321);
            dgvPurchase.Name = "dgvPurchase";
            dgvPurchase.ReadOnly = true;
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle8.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle8.ForeColor = Color.White;
            dataGridViewCellStyle8.SelectionBackColor = Color.FromArgb(59, 93, 79);
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.True;
            dgvPurchase.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            dgvPurchase.RowHeadersVisible = false;
            dgvPurchase.RowHeadersWidth = 51;
            dgvPurchase.Size = new Size(475, 495);
            dgvPurchase.TabIndex = 5;
            dgvPurchase.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgvPurchase.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgvPurchase.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgvPurchase.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgvPurchase.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgvPurchase.ThemeStyle.BackColor = Color.LightGray;
            dgvPurchase.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgvPurchase.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgvPurchase.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvPurchase.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            dgvPurchase.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgvPurchase.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgvPurchase.ThemeStyle.HeaderStyle.Height = 50;
            dgvPurchase.ThemeStyle.ReadOnly = true;
            dgvPurchase.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgvPurchase.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvPurchase.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            dgvPurchase.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgvPurchase.ThemeStyle.RowsStyle.Height = 29;
            dgvPurchase.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgvPurchase.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgvPurchase.CellClick += dgvPurchase_CellClick;
            // 
            // frmSupplier
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1214, 819);
            Controls.Add(btnViewDetail);
            Controls.Add(gbPurchaseHistory);
            Controls.Add(pnButton);
            Controls.Add(gbInfo);
            Controls.Add(dgvSupplier);
            Controls.Add(dgvPurchase);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "frmSupplier";
            Text = "frmSupplier";
            Load += frmSupplier_Load;
            ((System.ComponentModel.ISupportInitialize)pbArrow).EndInit();
            panel1.ResumeLayout(false);
            pnPurchase.ResumeLayout(false);
            pnPurchase.PerformLayout();
            gbPurchaseHistory.ResumeLayout(false);
            pnButton.ResumeLayout(false);
            pnInfo.ResumeLayout(false);
            pnInfo.PerformLayout();
            gbInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvSupplier).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvPurchase).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button btnViewDetail;
        private Label lbInvoiceId;
        private TextBox txtInvoiceId;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpTimeTo;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpTimeFrom;
        private PictureBox pbArrow;
        private Panel panel1;
        private Panel pnPurchase;
        private Guna.UI2.WinForms.Guna2GroupBox gbPurchaseHistory;
        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2Button btnSearch;
        private Guna.UI2.WinForms.Guna2Button btnMod;
        private FlowLayoutPanel pnButton;
        private Panel pnInfo;
        private TextBox txtName;
        private TextBox txtAddress;
        private Label lbAddress;
        private Label lbName;
        private TextBox txtId;
        private Label lbId;
        private Guna.UI2.WinForms.Guna2GroupBox gbInfo;
        private Guna.UI2.WinForms.Guna2DataGridView dgvSupplier;
        private Guna.UI2.WinForms.Guna2DataGridView dgvPurchase;
        private TextBox txtPhoneNumber;
        private Label label1;
        private TextBox txtEmail;
        private Label label2;
        private TextBox txtWebsite;
        private Label lbWebsite;
        private Guna.UI2.WinForms.Guna2Button btnAdd;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
    }
}